# -*- coding: utf-8 -*-
"""
Created on Tue Mar 24 00:54:20 2015

@author: Shilpa
"""


from Process_Simulation import input
import scipy 
import numpy
import matplotlib.pyplot as plt
from scipy.optimize import leastsq


class Abs():
    def __init__(self,co2,ch4,h2o,h2s):
        self.co2=co2
        self.h2s=h2s
        self.ch4=ch4
        self.h2o=h2o
        self.Fv_co2=input.Fv_co2
        self.Fv_h2o=input.Fv_h2o
        self.Fv_ch4=input.Fv_ch4
        self.Fv_h2s=input.Fv_h2s
        self.Fl_co2=input.Fl_co2
        self.Fl_h2o=input.Fl_h2o
        self.Fl_ch4=input.Fl_ch4
        self.Fl_h2s=input.Fl_h2s        
        self.kga=input.kga
        self.kla=input.kla
        self.D=input.D
        self.L=input.L
        self.P=input.P
        self.n=input.n
        self.S=input.S
        
        self.H_co2=input.H_co2
        self.H_h2s=input.H_h2s
        self.H_ch4=input.H_ch4
        self.H_h2o=input.H_h2o
        
             
        self.rho=input.rho
        
    def set_grid(self):
        #grid of initial guesses total 8 guesses 4 in liqd 4 in vapour
        
        """LIQUID"""
        self.Fl_co2_guess=scipy.ones(self.n)*self.Fl_co2
        self.Fl_ch4_guess=scipy.ones(self.n)*self.Fl_ch4
        self.Fl_h2o_guess=scipy.ones(self.n)*self.Fl_h2o
        self.Fl_h2s_guess=scipy.ones(self.n)*self.Fl_h2s
        """VAPOUR"""
        self.Fv_co2_guess=scipy.ones(self.n)*self.Fv_co2        
        self.Fv_ch4_guess=scipy.ones(self.n)*self.Fv_ch4
        self.Fv_h2o_guess=scipy.ones(self.n)*self.Fv_h2o
        self.Fv_h2s_guess=scipy.ones(self.n)*self.Fv_h2s
        
        
        
        self.guess=scipy.concatenate((self.Fl_co2_guess,self.Fl_ch4_guess,self.Fl_h2o_guess,self.Fl_h2s_guess,self.Fv_co2_guess,self.Fv_ch4_guess,self.Fv_h2o_guess,self.Fv_h2s_guess))
                      
        self.dx=self.L/(self.n-1)
        
    def solve(self):
        guess=self.guess
        soln=scipy.optimize.leastsq(residuals,guess,args=(self))[0]
        
def residuals(guess,obj):
   n=obj.n
   dx=obj.dx
   P=obj.P
   L=obj.L
   S=obj.S
   
   H_co2=obj.H_co2
   H_ch4=obj.H_ch4
   H_h2o=obj.H_h2o
   H_h2s=obj.H_h2s
   
   rho=obj.rho
            
   co2=obj.co2
   h2s=obj.h2s
   ch4=obj.ch4
   h2o=obj.h2o
   
   kla=obj.kla
   kga=obj.kga
   
   Fvin=obj.Fvin
   Flin=obj.Flin
   
   Fv_co2=obj.Fv_co2
   Fv_ch4=obj.Fv_ch4
   Fv_h2s=obj.Fv_h2s
   Fv_h2o=obj.Fv_h2o
   
   Fl_co2=obj.Fl_co2
   Fl_ch4=obj.Fl_ch4
   Fl_h2s=obj.Fl_h2s
   Fl_h2o=obj.Fl_h2o
   
   Fv_co2=guess[:n]
   Fv_ch4=guess[:n]
   Fv_h2s=guess[:n]
   Fv_h2o=guess[:n]

   Fl_co2=guess[:n]
   Fl_ch4=guess[:n]
   Fl_h2s=guess[:n]
   Fl_h2o=guess[:n]
   
   
   Fv_co2[0]=obj.Fv_co2
   Fv_ch4[0]=obj.Fv_ch4  #end points
   Fv_h2s[0]=obj.Fv_h2s
   Fv_h2o[0]=obj.Fv_h2o
   
   
   Fl_co2[-1]=obj.Fl_co2
   Fl_ch4[-1]=obj.Fl_ch4
   Fl_h2s[-1]=obj.Fl_h2s
   Fl_h2o[-1]=obj.Fl_h2o
   
   
   """for co2"""
   Rco2_num=scipy.ones(n)
   Rco2_den=scipy.ones(n)
   ErrFv_co2=scipy.ones(n)
   ErrFl_co2=scipy.ones(n)
   Rco2_num=((((P*Fv_co2/(Fv_co2+Fv_ch4+Fv_h2o+Fv_h2s))/(H_co2)))-((Fl_co2*rho)/Flin))
   Rco2_den=(1/(H_co2*kga))+(1/kla)
   
   x_co2=numpy.array(Fv_co2)
   y=numpy.diff(x_co2,n=dx)
   
   ErrFv_co2=y+(S*(Rco2_num/ Rco2_den))
   return ErrFv_co2
   
   
   
   
   
   
   



