# -*- coding: utf-8 -*-
"""
Created on Tue Mar 24 00:48:13 2015

@author: Shilpa
"""

import scipy as sc

L=5 #m
D=0.5 #m
P=101325 #Pa
n=10 #gridsize

Tvin=303.15 #K
Tlin=303.15 #K

Fvin=100 #kmol/s
"""" given mol% """
Fv_co2=0.45*Fvin
Fv_h2s=0.05*Fvin
Fv_h2o=0.00*Fvin
Fv_ch4=0.50*Fvin #no water in inlet gas

Flin=1000 #kmol/s

Fl_co2=0.0*Flin
Fl_h2s=0.0*Flin
Fl_h2o=Flin
Fl_ch4=0*Flin #pure water as inlet.

#calculating area 
S=(sc.pi*D**2)/4
kla=0.5
kga=0.1
rho=55.55  #molar density

#model for kla and kga


"""HENRYS CONSTANT FOR EACH"""
H_co2=5
H_h2s=10
H_ch4=60
H_h2o=100 #KUCH BHI !!!!! what is henry const fr water???











