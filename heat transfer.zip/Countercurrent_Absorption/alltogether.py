# -*- coding: utf-8 -*-
"""
Created on Tue Mar 24 00:52:47 2015

@author: Shilpa
"""

import scipy
from matplotlib import pyplot
from Process_Simulation import input
from Process_Simulation import absorption


chex=Abs(co2,ch4,h2o,h2s)
chex.set_grid()
Fl_co2=chex.Fl_co2[:chex.n]
m=scipy.ones(chex.n)
m[0]=0
for i in range (1,chex.n):
    x[i]=x[i-1]+chex.dx
fig=pyplot.figure()
ax=fig.add_subplot(121); fig.show()
pyplot.axis()
ax.plot(x,Fv_co2,'r')







