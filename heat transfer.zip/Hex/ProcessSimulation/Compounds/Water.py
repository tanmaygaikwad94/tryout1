# -*- coding: utf-8 -*-
"""
Created on Tue Feb 03 04:23:09 2015

@author: R014Tx
"""

import scipy 
import numpy
#Water
MW=18.015
Tc=647.096 #K
Pc=22.064e6 #pa
Zc=0.229
acc=0.3449
Hf=-24.1814e7 #J/kmol
Gf=-22.859e7 #J/kmol
Tf=298.15 #K
Pf=101325 #Pa  
Tb_1_atm=273.16+100           #k
def Psat(T):
    C1=73.649
    C2=-7258.2
    C3=-7.3037
    C4=4.1653*10**-6
    C5=2
    # P=Pa T=K
    Psat=scipy.exp(C1+(C2/T)+(C3*scipy.log(T))+(C4*T**C5))
    return Psat
    
def dens(T): #water 
    x=1-(T/647.096)
    rho=17.863+58.606*(x**0.35)-95.396*(x**2/3)+213.89*x-141.26*(x**(4/3)) #kmol/m3
    return rho
    
def Hvap(T):
    Tc=647.096
    Tr=T/Tc  # hv=J/kmol T,Tc =K
    C1=5.2053*10**7
    C2=0.3199
    C3=-0.212
    C4=0.25795
    C5=0 #water
    Hv=C1*(1-Tr)**(C2+(C3*Tr)+(C4*Tr**2)+(C5*Tr**3))
    return Hv
    
def CpL(T):
    #Cp=J/kmol k , T=K
    C1=276370
    C2=-2090.1
    C3=8.125
    C4=-0.014116
    C5=9.3701*10**-6 #water
    CpL=C1+(C2*T)+(C3*T**2)+(C4*T**3)+(C5*T**4)
    return CpL
    
def CpG(T): #J/(kmol K)
    C1=0.3336*10**5;C2=0.2679*10**5;C3=2.6015*10**3;C4=0.08896*10**5;C5=1169
    cpg=C1+C2*(((C3/T)/(numpy.sinh(C3/T)))**2)+C4*((C5/T)/(numpy.cosh(C5/T)))**2
    return cpg 
    
def viscL(T):  #Pa-s
    c1=-52.843
    c2=3703.6
    c3=5.866
    c4=-5.879*10**-29
    c5=10 
    mu=scipy.exp(c1+(c2/T)+c3*scipy.log(T)+c4*(T**c5))
    return mu

def viscG(T):  #Pa-s
    C1=1.7096E-8
    C2=1.1146
    C3=0
    C4=0 #benzene
    mu=((C1*(T**C2))/(1+(C3/T)+(C4/T**2)))  
    return mu
    
    
f=dens(450)
print(f)
