# -*- coding: utf-8 -*-
"""
Created on Wed Feb 18 00:34:07 2015

@author: Shilpa
"""
import scipy as sc
from scipy.interpolate import UnivariateSpline
from scipy import integrate
from ProcessSimulation.Compounds import Water,Benzene
import matplotlib.pyplot as plt

T1=sc.linspace(303.16,373.16,30) #liqd water from 30 to 100 bp of water
T2=sc.linspace(373.16,443.16,30) #vapour water from 100 to some big value ??
T3=sc.linspace(303.16,353.26,30) #liqd benzene from 30 to 80 bp of benzene
T4=sc.linspace(353.26,443.16,30) #vapour benzene from 80 to some big value ??

Hvap_w=sc.ones(len(T2)) #enthalpy of vap w
Hliq_w=sc.ones(len(T1)) #enthalpy of liq w

Hvap_b=sc.ones(len(T4)) #enthalpy of vap b
Hliq_b=sc.ones(len(T3)) #enthalpy of liq b

Psat_w=sc.ones(len(T1))
Psat_b=sc.ones(len(T3))

for t in range(0,len(T1)):
    Psat_w[t]=Water.Psat(T1[t]) #saturation pressure -liqd part   
    Hliq_w[t]=sc.integrate.quad(Water.CpG,298.15,T1[t])[0]+Water.Hf-Water.Hvap(373.16)
#mCpgdT+enthalpy of formation Hf -latent heat at Tsat i.e Hvap at 100 degrees celcius
    
    #Univariate spline
T_Psat_w=sc.interpolate.UnivariateSpline(Psat_w,T1,k=3,s=0)
#obtaining T from Psaturation
T_Hliq_w=sc.interpolate.UnivariateSpline(Hliq_w,T1,k=3,s=0)
  #obtaining T from Hliqd  
    
    #similarly for benzene
for t in range(0,len(T3)): #benzene liq
    Hliq_b[t]=sc.integrate.quad(Benzene.CpG,298.15,T2[t])[0]+Benzene.Hf-Benzene.Hvap(353.26)
    Psat_b[t]=Benzene.Psat(T3[t])
    
T_Psat_b=sc.interpolate.UnivariateSpline(Psat_b,T3,k=3,s=0)

    
    
    
for t in range(0,len(T2)): # water - vapour
    Hvap_w[t]=sc.integrate.quad(Water.CpG,298.16,T1[t])[0]+Water.Hf
T_Hvap_w=sc.interpolate.UnivariateSpline(Hvap_w,T2,k=3,s=0)
  
for t in range(0,len(T4)):  # benzene - vapour 
    Hvap_b[t]=sc.integrate.quad(Benzene.CpG,298.16,T4[t])[0]+Benzene.Hf
T_Hvap_b=sc.interpolate.UnivariateSpline(Hvap_b,T4,k=3,s=0)



plt.plot(T1,Hliq_w)
plt.plot(T2,Hvap_w)
plt.plot(T3,Hliq_b)
plt.plot(T4,Hvap_b)


plt.show()

#A:Benzene (Pipe)
#B:Water (Annulus)
Do=10
Di=5
m_a=1
m_p=2
a_Tin=100+273.16
p_Tin=30+273.16
n=10
pressure=1.01325*10**5
Kv_w=0.016 #conductivity
Kl_w=0.58
Kv_b=0.127
Kl_b=0.144
L=500
A=500


    
