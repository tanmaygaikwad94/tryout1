# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <markdowncell>

# #introduction#
# ##subintro##

# <markdowncell>

# $P=\frac{RT}{V-b}-\frac{a\alpha}{(V+\\epsilon b)(V+\sigma b)}$

# <codecell>

from sympy import init__session
init_session()

# <codecell>

from sympy import init_session
init_session()

# <codecell>

x

# <codecell>

s

# <codecell>

x

# <codecell>

P,R,T,V,s,e,z,a,alpha,b=symbols('P,R,T,V,sigma,epsilon,z,a,alpha,b')

# <codecell>

LHS=P
RHS=R*T/(V-b)-a*alpha/(V+e*b)/(V+s*b)
Eq(LHS,RHS)

# <codecell>

tRHS=together(RHS)
tRHS=fraction(tRHS)
tRHS

# <codecell>

tRHS=together(RHS)
tRHS=fraction(tRHS)
nr=tRHS[0];dr=tRHS[1]
cub=LHS*dr-nr;cub=cub.expand().subs(V,z*R*T/P)
cub=cub.collect(z)
cub=(cub*P**2/(R*T)**3).expand().collect(z)

Eq(cub,0)

# <codecell>

cub.coeff(z,1)

# <codecell>

cub.coeff(z,3)

# <codecell>

print cub.coeff(z,2)

# <codecell>

print cub.coeff(z,3)

# <codecell>

print cub.coeff(z,1)

# <codecell>


