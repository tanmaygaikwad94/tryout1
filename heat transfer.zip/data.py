# -*- coding: utf-8 -*-
"""
Created on Tue Feb 17 14:46:51 2015

@author: Ankit
"""

import scipy 
from scipy.interpolate import UnivariateSpline
from scipy import integrate
from Process_Simulation.Compounds import water,benzene
import matplotlib.pyplot as plt
Tl_w=scipy.linspace(303.16,373.16,30)
Tv_w=scipy.linspace(373.16,500.16,30)
Tl_b=scipy.linspace(303.16,353.16,30)
Tv_b=scipy.linspace(353.16,500.16,30)
Hl_w=scipy.ones(len(Tl_w))  #enthalpy of liq. water
Hl_b=scipy.ones(len(Tl_b))   #enthalpy of liq. benzene
Hv_w=scipy.ones(len(Tv_w))  #enthalpy of vap water
Hv_b=scipy.ones(len(Tv_b))
Psat_w=scipy.ones(len(Tl_w))  #Psat
Psat_b=scipy.ones(len(Tl_b))


for i in range (0,len(Tl_w)):
    Hl_w[i]=water.Hf+scipy.integrate.quad(water.CpG,water.Tf,Tl_w[i])[0]-water.Hvap(water.Tb)
        #Hf@25+mCpgdT-LatentHeat @ Tsat only
    Psat_w[i]=water.Psat(Tl_w[i])
        #Psat only for liquid part
TfromHl_w=scipy.interpolate.UnivariateSpline(Hl_w,Tl_w,k=3,s=0)
TfromP_w=scipy.interpolate.UnivariateSpline(Psat_w,Tl_w,k=3,s=0)
#satration Temp of water
Tsat_w=TfromP_w(101325)
print "Tsat_w: "
print Tsat_w

for i in range (0,len(Tv_w)):
    Hv_w[i]=water.Hf+scipy.integrate.quad(water.CpG,water.Tf,Tv_w[i])[0]
        #Hf@25+mCpgdT
TfromHv_w=scipy.interpolate.UnivariateSpline(Hv_w,Tv_w,k=3,s=0)


for i in range (0,len(Tl_b)):
    Hl_b[i]=benzene.Hf+scipy.integrate.quad(benzene.CpG,water.Tf,Tl_b[i])[0]-benzene.Hvap(benzene.Tb)
        #Hf@25+mCpgdT-Latent
    Psat_b[i]=benzene.Psat(Tl_b[i])
    
for i in range (0,len(Tl_b)):
    Hv_b[i]=benzene.Hf+scipy.integrate.quad(benzene.CpG,water.Tf,Tv_b[i])[0]

TfromP_b=scipy.interpolate.UnivariateSpline(Psat_b,Tl_b,k=3,s=0)
TfromHl_b=scipy.interpolate.UnivariateSpline(Hl_b,Tl_b,k=3,s=0)
TfromHv_b=scipy.interpolate.UnivariateSpline(Hv_b,Tv_b,k=3,s=0)
Tsat_b=TfromP_b(101325)
print "Tsat_b: "
print Tsat_b

print "Hl_w: "
print Hl_w
print Hv_w
print Hl_b
print Hv_b

plt.plot(Tl_w,Hl_w)
plt.plot(Tv_w,Hv_w)
plt.plot(Tl_b,Hl_b)
plt.plot(Tv_b,Hv_b)


plt.show()
#Data required is being put here
"""A:Benzene (Pipe)
B:Water (Annulus)"""
mA=2
mB=1
do=2
di=1
Kv_w=0.016 #conductivity values
Kl_w=0.58
Kv_b=0.127
Kl_b=0.144
L=10
A_HT=scipy.pi*do*L #Area of Heat Transfer
A_flow_A=(scipy.pi*di**2)/4
A_flow_B=(scipy.pi*(do**2-di**2))/4
n=10
P=101325
Tin_A=373.16
Tin_B=303.16
