# -*- coding: utf-8 -*-
"""
Created on Tue Jan 20 10:00:26 2015

@author: vhd
"""

import scipy as sc
import matplotlib.pyplot as plt
import scipy.optimize as opt
mh=1 
mc=2
Thin=373.15 
Tcin=303.15 
U=300
A=10 
n=10
Thguess=n*[Thin] #guess is inlet value 
Tcguess=n*[Tcin] #no of elements in an array
Tguess=sc.array(Thguess+Tcguess)
def CpH(T):  #function of temp
    CpH=4.184+(10**-9)*T**3+(10**-6)*T**2+(10**-4)*T
    return CpH
def CpC(T):    #function of temp
    CpC=4.184+(10**-9)*T**3+(10**-6)*T**2+(10**-4)*T
    return CpC
def dphefinal(T,U,A,Thin,Tcin,mh,mc):
    n=len(T)
    Th=T[:n/2] #first n/2 elements to the left of n/2
    Tc=T[n/2:]
    dA=A/((n/2)-1) #unknowns at boundaries also, so n/2-1 parts thus divide are
    errHL=(U*(Thin-Tc[0])/(mh*CpH(Thin)*1000))+((Th[1]-Thin)/dA)
    errCL=(U*(Thin-Tc[0])/(mc*CpC(Tc[0])*1000))+((Tc[1]-Tc[0])/dA)
    errHR=(U*(Th[-1]-Tcin)/(mh*CpH(Th[-1])*1000))+((Th[-1]-Th[-2])/dA)
    errCR=(U*(Th[-1]-Tcin)/(mc*CpC(Tcin)*1000))+((Tcin-Tc[-2])/dA)
    errH=sc.zeros(n/2)
    errC=sc.zeros(n/2)
    errH[0]=errHL; errH[-1]=errHR #errors at boundary points
    errC[0]=errCL;errC[-1]=errCR
    errH[1:-1]=(U*(Th[1:-1]-Tc[1:-1])/(mh*CpH(Th[1:-1])*1000))+((Th[2:])-Th[1:-1])/dA
    errC[1:-1]=(U*(Th[1:-1]-Tc[1:-1])/(mc*CpC(Tc[1:-1])*1000))+((Tc[2:])-Tc[1:-1])/dA
    return sc.concatenate((errH,errC))
#minimising error using least square
n=len(Tguess)   
soln=opt.leastsq(dphefinal,Tguess,args=(U,A,Thin,Tcin,mh,mc))
Tsoln=soln[0]
Thsoln=Tsoln[:n/2]
Thsoln[0]=Thin
Tcsoln=Tsoln[n/2:]
Tcsoln[-1]=Tcin
print Thsoln
print Tcsoln
#plot graph
grp=sc.linspace(0, 100,10)
plt.plot(grp, Thsoln,'r')
plt.show()
plt.plot(grp,Tcsoln,'b')
plt.show()