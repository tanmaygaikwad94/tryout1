# -*- coding: utf-8 -*-
"""
Created on Tue Jan 20 11:54:38 2015

@author: vhd
"""

import scipy 
from scipy.integrate import quad
Thin=373.15 
Tcin=303.15
Thout=343.59
Tcout=318.09
CpC=4.184+(10**-9)*T**3+(10**-6)*T**2+(10**-4)*T
CpH=4.184+(10**-9)*T**3+(10**-6)*T**2+(10**-4)*T
def integrand(T)
I=quad(integrand,Thout,Tcin)