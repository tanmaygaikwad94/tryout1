# -*- coding: utf-8 -*-
"""
Created on Sun Mar 15 11:57:49 2015

@author: Ankit
"""
import scipy
#data file
kla=0.001  #/s
kga=0.05    #/s
P=101325  #Pa
n=10
H=100
rhoL=55.55  #molar density
#Hco2=5
#Hh2s=10
#Hch4=60
#Hh2o=100
#Fvco2in=40
#Flh2oin=100
#Fvh2oin=0
#Flco2in=0
#Flh2sin=0
#Flch4in=0
#Fvh2oin=0
#Fvh2sin=5
#Fvch4in=50
#Fv=100
#Fl=100
#Tco2in=400
#Th2sin=400
#Tch4in=400
#Th2oin=300
Tlin=30
Tvin=300
S=10