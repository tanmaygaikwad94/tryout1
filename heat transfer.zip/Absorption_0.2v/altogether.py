# -*- coding: utf-8 -*-
"""
Created on Sun Mar 15 23:26:09 2015

@author: KasturiSarang
"""
import absorption 
#import absorption.Compounds.h2o as h2o
#import absorption.Compounds.ch4 as ch4
#import absorption.Compounds.co2 as co2
#import absorption.Compounds.h2s as h2s
#import absorption.fluid.fluid as fluid
import co2,ch4,h2s,h2o
Compounds={'co2':co2,'ch4':ch4,'h2s':h2s,'h2o':h2o}
from absorption.exam import Exam
from matplotlib import pyplot
#import data
import matplotlib.pyplot as plt
solves=Exam()
solves.set_grid()
solves.solve()
x=[1,2,3,4,5,6,7,8,9,10]


fig=plt.figure()
ax= fig.add_subplot(341); fig.show()
plt.axis()
ax.plot(x,solves.Fvh2osoln,'r')
bx=fig.add_subplot(342); fig.show()
plt.axis()
bx.plot(x,solves.Flh2o,'b')
cx= fig.add_subplot(343); fig.show()
plt.axis()
cx.plot(x,solves.Fvh2ssoln,'r')
dx= fig.add_subplot(344); fig.show()
plt.axis()
dx.plot(x,solves.Flh2s,'b')
ex= fig.add_subplot(345); fig.show()
plt.axis()
ex.plot(x,solves.Fvco2soln,'r')
fx= fig.add_subplot(346); fig.show()
plt.axis()
fx.plot(x,solves.Flco2,'b')
gx= fig.add_subplot(347); fig.show()
plt.axis()
gx.plot(x,solves.Fvch4soln,'r')
hx= fig.add_subplot(348); fig.show()
plt.axis()
hx.plot(x,solves.Flch4,'b')
ix= fig.add_subplot(349); fig.show()
plt.axis()
ix.plot(x,solves.T,'c')