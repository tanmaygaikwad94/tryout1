# -*- coding: utf-8 -*-
"""
Created on Tue Feb 17 16:01:59 2015

@author: Shilpa
"""
import scipy as sc
import scipy.integrate
from scipy.interpolate import UnivariateSpline 
from ProcessSimulation.Compounds import benzene
from ProcessSimulation.Compounds import water
import matplotlib.pyplot as plt


