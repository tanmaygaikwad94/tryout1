# -*- coding: utf-8 -*-
"""
Created on Tue Jan 20 03:06:39 2015

@author: R014Tx
"""

import scipy as sc
import matplotlib.pyplot as plt
import scipy.optimize as opt
mh=1 #unit-kg/s
mc=2 #unit-kg/s
Thin=373.15 #unit-K
Tcin=303.15 #unit-K
U=300 #unit-W/m2
A=100 #unit-m2
n=10
Thguess=n*[Thin] #guess is inlet value eg 10*[3] is  ten times 3 array
Tcguess=n*[Tcin] #no of elements in an array
Tguess=sc.array(Thguess+Tcguess) #if you add lists they concatenate, arrays add,
#here theys are lists 8
def CpH(T):
    CpH=4.184+(10**-9)*T**3+(10**-6)*T**2+(10**-4)*T
    return CpH
def CpC(T):
    CpC=4.184+(10**-9)*T**3+(10**-6)*T**2+(10**-4)*T
    return CpC
def residuals(T,U,A,Thin,Tcin,mh,mc):
    n=len(T)
    Th=T[:n/2] #first n/2 elements to the left of n/2
    Tc=T[n/2:]
    dA=A/((n/2)-1) #unknowns at boundaries also, so n/2-1 parts thus divide are
    errHL=(U*(Thin-Tc[0])/(mh*CpH(Thin)))+((Th[1]-Thin)/dA)
    errCL=(U*(Thin-Tc[0])/(mc*CpC(Tc[0])))+((Tc[1]-Tc[0])/dA)
    errHR=(U*(Th[-1]-Tcin)/(mh*CpH(Th[-1])))+((Th[-1]-Th[-2])/dA)
    errCR=(U*(Th[-1]-Tcin)/(mc*CpC(Tcin)))+((Tcin-Tc[-2])/dA)
    errH=sc.zeros(n/2)
    errC=sc.zeros(n/2)
    errH[0]=errHL; errH[-1]=errHR #errors at boundary points
    errC[0]=errCL;errC[-1]=errCR
    errH[1:-1]=(U*(Th[1:-1]-Tc[1:-1])/(mh*CpH(Th[1:-1])))+((Th[2:])-Th[1:-1])/dA
    #forward
    errC[1:-1]=(U*(Th[1:-1]-Tc[1:-1])/(mc*CpC(Tc[1:-1])))+((Tc[2:])-Tc[1:-1])/dA
    #forward
    # errH[1:-1]=(u*(th[1:-1]-tc[1:-1])/(mh*Cph(Th[1:-1])))+(th[2:])-th[0:-2])/dA
    #central
    #errC[1:-1]=(u*(th[1:-1]-tc[1:-1])/(mc*Cpc(Tc[1:-1])))+(tc[2:])-tc[0:-2])/dA
    #central
    return sc.concatenate((errH,errC))
    print errH
    print errC
n=len(Tguess)   
soln=opt.leastsq(residuals,Tguess,args=(U,A,Thin,Tcin,mh,mc))
Tsoln=soln[0]
Thsoln=Tsoln[:n/2]
Thsoln[0]=Thin
Tcsoln=Tsoln[n/2:]
Tcsoln[-1]=Tcin
print Thsoln
print Tcsoln



b=sc.linspace(0, 100,10)
plt.plot(b, Thsoln,'r')
plt.show()
plt.plot(b,Tcsoln,'b')
plt.show()


