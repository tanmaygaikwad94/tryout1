# -*- coding: utf-8 -*-
"""
Created on Sun Jan 18 13:08:15 2015

@author: Girija
"""

import numpy as np
import matplotlib.pyplot as plt

'''Z=np.array([[0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0],
            [0,0,0,0,1,0,0],
            [0,0,0,0,1,0,0],
            [0,0,0,0,1,0,0],
            [0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0]])'''
Z = np.random.randint(0,2,(30,10))
print Z

                     
def iterate(Z):
    N=np.zeros(Z.shape,dtype=int)
    N[1:-1,1:-1]+=(Z[ :-2, :-2] + Z[ :-2,1:-1] + Z[ :-2,2:] +
                     Z[1:-1, :-2]                + Z[1:-1,2:] +
                     Z[2:  , :-2] + Z[2:  ,1:-1] + Z[2:  ,2:])
 
    
    birth = (N==3) & (Z==0)
    survive = ((N==2) | (N==3)) & (Z==1)
    Z[...] = 0   
    Z[...][birth | survive] = 1
    
    
    return Z
    


fig = plt.figure()
ax=fig.add_subplot(111)
        
for i in range(100):
    iterate(Z)
   
    ax.clear()
    ax.imshow(Z,interpolation='nearest', cmap=plt.cm.gray_r)
    
    plt.show()
    plt.pause(0.5)
    
    
    
print Z



    

