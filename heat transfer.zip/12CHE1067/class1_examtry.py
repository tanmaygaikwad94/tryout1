# -*- coding: utf-8 -*-
"""
Created on Sun Apr 19 21:04:48 2015

@author: R014Tx
"""

import scipy as sc
import scipy.optimize as opt
from scipy import integrate
import matplotlib.pyplot as plt

class DPHEx:
    def __init__(self,A,U,mh,Thin,mc,Tcin,n):
        self.A=A
        self.U=U
        self.set_hex(mh,Thin,mc,Tcin)
        self.set_grid(n)
        
    def set_hex(mh,Thin,mc,Tcin):
        self.mh=mh
        self.Thin=Thin
        self.mc=mc
        self.Tcin=Tcin
        
    def set_grid(self,n):
        self.n=n
        self.Th=sc.ones(n)*self.Thin
        self.Tc=sc.ones(n)*self.Tcin
        self.dA=self.A/(n-1)
        self.Tguess=sc.concatenate((self.Th,self.Tc))
        
    def solve(self):
        Tguess=self.Tguess
        Tsoln=opt.leastsq(residuals,Tguess,args=(self))[0]
        self.Th=Tsoln[:self.n]
        self.Tc=Tsoln[self.n:]
        
        print self.Th
        print self.Tc
        
    def check(self):
        def Cp(t):
            y=(4.184+(10**-4)*t+(10**-6)*(t**2)+(10**-9)*(t**3))*1000
            return y
            
            self.t1=sc.integrate.quad(Cp,self.Th[0],self.Th[-1])
            self.t2=sc.integrate.quad(Cp,self.Tc[0],self.Tc[-1])
            self.z=(abs((1*self.t1[0]-2*self.t2[0])/self.t1[0])*100
            return self.z
def cph(t):
    y= 4.184+(10**-4)*t+(10**-6)*(t**2)+(10**-9)*(t**3)
    return y
def cpc(t):
    y= 4.184+(10**-4)*t+(10**-6)*(t**2)+(10**-9)*(t**3)
    return y     
def residuals(T,obj):
    n=obj.n
    Thm=obj.Thin
    Tcm=obj.Tcin
    Th=obj.T[:n]
    Tc=obj.T[n:]
    dA=obj.dA
    U=obj.U
    mc=obj.mc
    mh=obj.mh
    Th[0]=Thm
    Tc[-1]=Tcm
    errh=scipy.ones(n)
    errc=scipy.ones(n)
    errc[0]=(Tc[1]-Tc[0])/dA+U*(Th[0]-Tc[0])/(mc*cpc(Tc[0])*1000)
    errh[0]=(Th[1]-Th[0])/dA+U*(Th[0]-Tc[0])/(mh*cph(Th[0])*1000)
    errc[-1]=(Tc[-1]-Tc[-2])/dA+U*(Th[-1]-Tc[-1])/(mc*cpc(Tc[-1])*1000)
    errh[-1]=(Th[-1]-Th[-2])/dA+U*(Th[-1]-Tc[-1])/(mh*cph(Th[-1])*1000)

    for i in range(1,n-1):
        errc[i]=(U*(T(i+1)-T(i))/(mh*cph(T(i+1))))

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
        