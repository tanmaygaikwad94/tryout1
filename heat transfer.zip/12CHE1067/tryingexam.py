# -*- co  ding: utf-8 -*-
"""
Created on Sun Apr 19 11:28:00 2015

@author: R014Tx
"""

import scipy as sc
import matplotlib.pyplot as plt
import scipy.optimize as opt
mh=1; mc=2
Thin=373.16; Tcin=303.16
U=300; A=100
n=10

Thguess=n*[Thin]; Tcguess=n*[Tcin]
Tguess=sc.array(Thguess+Tcguess)
def Cp(T):
    Cp=[(4.184+(10**-9)*T**3+(10**-6)*T**2+(10**-4)*T)*1000]
    return Cp
def residuals(T,U,A,Thin,Tcin,mh,mc):
    n=len(T)
    Th=T[:n/2]
    Tc=T[n/2:]
    dA=A/((n/2)-1)
    errHL=(U*(Thin-Tc[0])/(mh*Cp(Thin)*1000))+((Th[1]-Thin)/dA)
    errCL=(U*(Thin-Tc[0])/(mc*Cp(Tc[0])*1000))+((Tc[1]-Tc[0])/dA)
    errHR=(U*(Th[-1]-Tcin)/(mh*Cp(Th[-1])*1000))+((Th[-1]-Th[-2])/dA)
    errCR=(U*(Th[-1]-Tcin)/(mc*Cp(Tcin)*1000))+((Tcin-Tc[-2])/dA)
    
    errH=sc.zeros(n/2)
    errC=sc.zeros(n/2)
    errH[0]=errHL; errH[-1]=errHR
    errC[0]=errCL; errC[-1]=errCR
    errH[1:-1]=(U*(Th[1:-1]-Tc[1:-1])/(mh*Cp(Th[1:-1])*1000))+((Th[2:]-Th[1:-1])/dA)  
    errC[1:-1]=(U*(Th[1:-1]-Tc[1:-1])/(mc*Cp(Tc[1:-1])*1000))+((Tc[2:]-Tc[1:-1])/dA)
    
    return sc.concatenate((errH,errC))

n=len(Tguess)
soln=opt.leastsq(residuals,Tguess,args=(U,A,Thin,Tcin,mh,mc))
Tsoln=soln[0]
Thsoln=Tsoln[:n/2]
Thsoln[0]=Thin
Tcsoln=Tsoln[n/2:]
Tcsoln[-1]=Tcin
print Thsoln
print Tcsoln
























