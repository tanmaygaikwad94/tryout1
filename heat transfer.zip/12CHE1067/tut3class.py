# -*- coding: utf-8 -*-
"""
Created on Tue Jan 20 12:33:41 2015

@author: vhd
"""

import scipy
import scipy.optimize as opt
class DPHEx:
    def __init__(self,A,U,mh,Thin,mc,Tcin,n,Cph,Cpc):
        self.Area=A
        self.U=U
        self.set_hex(mh,Thin,mc,Tcin)
        self.set_grid(n)
        self.set_Cph(Cph)
        self.set_Cpc(Cpc)
    def set_hex(self,mh,Thin,mc,Tcin):
        self.mh=mh
        self.Thin=Thin
        self.mc=mc
        self.Tcin=Tcin
    def set_grid(self,n):
        self.n=n
        self.Th=scipy.ones(n)*self.Thin #used attributes of the object
        self.Tc=scipy.ones(n)*self.Tcin 
        self.dA=self.A/(n-1)
        self.Tguess=scipy.concatenate((self.Th,self.Tc))
def residuals(T,obj):
    n=obj.n
    Thin=obj.Thin
    Tcin=obj.Tcin
    Th=T[:n]
    Tc=T[n:]
    dA=obj.dA
    #write the dphe prgm to find error (def check(self))
def solve(self):
    Tguess=self.Tguess
    Tsoln=opt.leastsq(residuals,Tguess,args=(self))
    self.Th=Tsoln[:self.n]
    self.Th[0]=self.Thin
    self.Tc=Tsoln[self.n:] 
    self.Tc[-1]=Tcin
     