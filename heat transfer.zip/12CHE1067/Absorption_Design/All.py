# -*- coding: utf-8 -*-
"""
Created on Sun Mar 15 13:34:36 2015

@author: Ankit
"""
import matplotlib.pyplot as plt
from Process1.Exam import Exam
solves=Exam()
solves.set_grid()
solves.solve()
x=[1,2,3,4,5,6,7,8,9,10]

"""plt.plot(x,solves.Fv_CO2,'r')
plt.show()
plt.plot(x,solves.Fl_CO2,'b')
plt.show()
plt.plot(x,solves.Fv_H2S,'r')
plt.show()
plt.plot(x,solves.Fl_H2S,'b')
plt.show()
plt.plot(x,solves.Fv_CH4,'r')
plt.show()
plt.plot(x,solves.Fl_CH4,'b')
plt.show()
plt.plot(x,solves.Fl_H2O,'b')
plt.show()
plt.plot(x,solves.Fv_H2O,'r')
plt.show()"""

fig=plt.figure()
ax= fig.add_subplot(241); fig.show()
plt.axis()
ax.plot(x,solves.Fv_H2O,'r')
bx=fig.add_subplot(242); fig.show()
plt.axis()
bx.plot(x,solves.Fl_H2O,'b')
cx= fig.add_subplot(243); fig.show()
plt.axis()
cx.plot(x,solves.Fv_H2S,'r')
dx= fig.add_subplot(244); fig.show()
plt.axis()
dx.plot(x,solves.Fl_H2S,'b')
ex= fig.add_subplot(245); fig.show()
plt.axis()
ex.plot(x,solves.Fv_CO2,'r')
fx= fig.add_subplot(246); fig.show()
plt.axis()
fx.plot(x,solves.Fl_CO2,'b')
gx= fig.add_subplot(247); fig.show()
plt.axis()
gx.plot(x,solves.Fv_CH4,'r')
hx= fig.add_subplot(248); fig.show()
plt.axis()
hx.plot(x,solves.Fl_CH4,'b')
ix= fig.add_subplot(249); fig.show()
plt.axis()
ix.plot(x,solves.T,'c')