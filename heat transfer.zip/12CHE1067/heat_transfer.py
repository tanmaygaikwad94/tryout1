# -*- coding: utf-8 -*-
"""
Created on Tue Jan 13 11:55:23 2015

@author: vhd
"""
import scipy
from scipy.optimize import leastsq
def cph(t):
    y= 4.184+(10**-4)*t+(10**-6)*(t**2)+(10**-9)*(t**3)
    return y

def cpc(t):
    y= 4.184+(10**-4)*t+(10**-6)*(t**2)+(10**-9)*(t**3)
    return y
U=300
mh=1
mc=2
Thin=373
Tcin=303
n=10
Thguess=scipy.array(n*[Thin])
Tcguess=scipy.array(n*[Tcin])
Tguess=scipy.concatenate((Thguess,Tcguess))
def error(T,U,mh,mc,Thin,Tcin):
    n=len(T)/2
    Th=T[:n]; Tc=T[n:]
    errh=scipy.ones(n)
    errc=scipy.ones(n)
    errc[0]=Tc[1]-Tc[0]+U*(Thin-Tc[0])/(mc*cpc(Tc[0])*1000)
    errh[0]=Th[1]-Thin+U*(Thin-Tc[0])/(mh*cph(Thin)*1000)
    errc[-1]=Tcin-Tc[-2]+U*(Th[-1]-Tcin)/(mc*cpc(Tcin)*1000)
    errh[-1]=Th[-1]-Th[-2]+U*(T[-1]-Tcin)/(mh*cph(Th[-1])*1000)
    for i in range (1,n-1):
        errc[i]=(Tc[1+i]-Tc[i-1])/2+U*(Th[i]-Tc[i])/(mc*cpc(Tc[i])*1000)
        errh[i]=(Th[1+i]-Th[i-1])/2+U*(Th[i]-Tc[i])/(mh*cph(Th[i])*1000)
    err=scipy.concatenate((errc,errh))
    return err

solution=scipy.optimize.leastsq(error,Tguess,args=(U,mh,mc,Thin,Tcin))
print solution



    

        
   
