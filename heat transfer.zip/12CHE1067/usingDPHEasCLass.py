# -*- coding: utf-8 -*-
"""
Created on Tue Jan 20 12:32:29 2015

@author: vhd
"""
import scipy
import scipy.optimize as opt

    #def set_CpH(self,f)
     #   self.CpH=f
    #def set_CpC(self,f)
     #   self.CpC=f
class DPHEx:
   def __int__(self,A,U,mh,Thin,mc,Tcin,n,CpH,CpC):
        self.Area=A
        self.U=U #assigning values A and U to attribute Area and U
        self.set_hex(mh,Thin,mc,Tcin)
        self.set_grid(n)
        self.set_CpH(CpH)
        self.set_CpC(CpC)
        #set_hex and set_grid are two functions which will be written next
        #we define the func in the class
        #first argument of the func is always going to be self when writing in class
        #The order shall remain same
        #OBJECT ORIENTED PROGRAMMING
        
        
   def set_hex(self,mh,Thin,mc,Tcin):
        #defining some more attribute
        #You can change inputs by changing these
        self.mh=mh
        self.mc=mc
        self.Thin=Thin
        self.Tcin=Tcin
        
    
        
   def set_grid(self,n):
       #makes the grid
        self.n=n
        self.Th=scipy.ones(n)*self.Thin
        #this func has used attributes of the object
        #self was not passed in line 12 
        #any attribute accessible to object can be part of any function
        
        self.Tc=scipy.ones(n)*self.Tcin
        self.dA=self.A/(n-1)
        #usually we write residuals as
        #residuals(T,U,A,Thin,Tcin,mh,mc):
        self.Tguess=scipy.concatanete((self.Th,self.Tc))
        
   def residuals (T,obj): #does not require string of arguments but just takes obj
       n=obj.n
       Thin=obj.Thin
       Tcin=obj.Tcin
       Th=T[:n]
       Tc=T[n:]
       dA=obj.dA
       
       
       
       
       
       
       return err
       #solve inside class and residuals outside the class
       #you cud write residuals in separate file
       
       #Today your writing temp as residuals tommorow you cn write conc ie u cn swap module for calculating the residuals
       #Residuals isnt something inherent to the dphe so we keep it outside the class
   def solve(self):
       Tguess=self.Tguess
       Tsoln=opt.leastsq(residuals,Tguess,args=(self))
       self.Th=soln[:self,n]
       self.Tc=soln[self,n:]
       self.Tc[-1]=Tcin
       
       