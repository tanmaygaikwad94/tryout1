# -*- coding: utf-8 -*-
"""
Created on Mon Apr 20 01:03:13 2015

@author: R014Tx
"""

import scipy as sc
import matplotlib.pyplot as plt
import numpy as np
from scipy.interpolate import UnivariateSpline

"""def f(x):
    y=sc.log((3*(x**2)+(2*x)+4))
    return y

x=sc.linspace(0,100,1000)
fig=plt.figure()
ax=fig.add_subplot(111)
fig.show()

i=1
for i in range(1,100):
    y=f(x)
    z=sc.interpolate.UnivariateSpline(y,x,k=3,s=0)
    ax.clear()
    ax.plot(y,z(y),'r')
    plt.pause(2)
i+=1
"""
def f(x):
    y=sc.exp(sc.sin((3*(x**2)+2*x+sc.cos(4*x))))
    return y
x=sc.linspace(0,100,1000)
fig=plt.figure()
ax=fig.add_subplot(111)
fig.show()

i=1
for i in range (1,100):
    y=f(x)
    ax.clear()
    ax.plot(x,y,'r')
    plt.pause(1)
i+=1

