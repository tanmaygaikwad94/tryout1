# -*- coding: utf-8 -*-
"""
Created on Mon Apr 20 03:11:18 2015

@author: R014Tx
"""

import scipy
from scipy import integrate
import matplotlib.pyplot as plt
"""import scipy
from scipy import integrate
import matplotlib.pyplot as plt


k1=0.1
k2=0.005
arrCo=[1,2,0,0]

tc=1.0/(k1*arrCo[1])
t=scipy.linspace(0,10*tc,1000)


def derv(arrC,t,arrK):
    [Ca,Cb,Cc,Cd]=arrC
    [k1,k2]=arrK
    
    dCa=-k1*Ca*Cb
    dCb=-k1*Ca*Cb-k2*Cc*Cb
    dCc=k1*Ca*Cb-k2*Cb*Cc
    dCd=k2*Cb*Cc
    arrDc=[dCa,dCb,dCc,dCd]
    return arrDc

C=scipy.integrate.odeint(derv,arrCo,t,args=([k1,k2],))
fig=plt.figure()
ax=fig.add_subplot(111)
ax.plot(t,C[:,0],'r')
ax.plot(t,C[:,1],'b')
ax.plot(t,C[:,2],'m')
ax.plot(t,C[:,3],'g')
fig.show()
fig.canvas.draw()"""

"""k1=0.1
k2=0.005
arrCo=[1,2,0,0]
tc=1.0/(k1*arrCo[1])
t=scipy.linspace(0,10*tc,1000)

def derv(arrC,t,arrK):
    [Ca,Cb,Cc,Cd]=arrC
    [k1,k2]=arrK
    
    dCa=-k1*Ca*Cb
    dCb=-k1*Ca*Cb-k2*Cc*Cb
    dCc=k1*Ca*Cb-k2*Cb*Cc
    dCd=k2*Cb*Cc
    arrDc=[dCa,dCb,dCc,dCd]
    return arrDc
    
C=scipy.integrate.odeint(derv,arrCo,t,args=([k1,k2],))
    
fig=plt.figure()
ax=fig.add_subplot(111)
ax.plot(t,C[:,0],'r')
ax.plot(t,C[:,1],'b')
ax.plot(t,C[:,2],'m')
ax.plot(t,C[:,3],'g')
fig.show()
fig.canvas.draw
    
    """
import numpy as np
import scipy as sp
from scipy.integrate import odeint
import matplotlib.pyplot as plt

def g(y, x):
    y0 = y[0]
    y1 = y[1]
    y2 = ((3*x+2)*y1 + (6*x-8)*y0)/(3*x-1)
    return y1, y2

# Initial conditions on y, y' at x=0
init = 2.0, 3.0
# First integrate from 0 to 2
x = np.linspace(0,2,100)
sol=odeint(g, init, x)
# Then integrate from 0 to -2
plt.plot(x, sol[:,0], color='b')
x = np.linspace(0,-2,100)
sol=odeint(g, init, x)
plt.plot(x, sol[:,0], color='b')

# The analytical answer in red dots
"""'exact_x = np.linspace(-2,2,10)
exact_y = 2*np.exp(2*exact_x)-exact_x*np.exp(-exact_x)
plt.plot(exact_x,exact_y, 'o', color='r', label='exact')
plt.legend()

plt.show()"""