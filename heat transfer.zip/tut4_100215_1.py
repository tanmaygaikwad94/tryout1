# -*- coding: utf-8 -*-
"""
Created on Tue Feb 10 12:04:33 2015

@author: vhd
"""

import scipy as sc
import numpy as np
import matplotlib.pyplot as plt

def f1(x):
    y=sc.exp(sc.sin((3*(x**2)+2*x+sc.cos(4*x))))
    return y
   
x=sc.linspace(0,100,1000)
fig=plt.figure()
ax=fig.add_subplot(111)
fig.show()
i=1
for i in range(1,100):
    y=f1(x)
    ax.clear()
    ax.plot(x,y,'r')
    plt.pause(1)
i+=1
    
    
