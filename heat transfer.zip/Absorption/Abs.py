# -*- coding: utf-8 -*-
"""
Created on Mon Mar 16 23:38:54 2015

@author: Shilpa
"""

import ProcessSimulation.input.input as ip
import scipy as sc
import ProcessSimulation
import ProcessSimulation.Compounds.water as water
import ProcessSimulation.Compounds.methane as CH4
import ProcessSimulation.Compounds.carbondioxide as CO2
import ProcessSimulation.Compounds.H2S as H2S
import ProcessSimulation.fluid.fluid as fluid
import numpy as np

class Abs:
    def __init__(self,a,b,c,d): 
        self.a=a
        self.b=b
        self.c=c
        self.d=d
        self.L=ip.L
        self.D=ip.D
        self.P=ip.P
        self.Tlin=ip.Tlin
        self.Tvin=ip.Tvin
        self.Fvin=ip.Fvin
        self.Flin=ip.Flin
        self.n=ip.n
        self.S=ip.S
        self.Fva_in=ip.Fva_in
        self.Fvb_in=ip.Fvb_in
        self.Fvc_in=ip.Fvc_in
        self.Fvd_in=ip.Fvd_in
        self.Fla_in=ip.Fla_in
        self.Flb_in=ip.Flb_in
        self.Flc_in=ip.Flc_in
        self.Fld_in=ip.Fld_in
        self.set_grid(self,n)
        
    def set_grid(self,n):    
        self.n=self.n
        a=self.a
        b=self.b
        c=self.c
        d=self.d
        
        self.dx=self.L/(n-1)
        
        self.Hv_in=self.Htot(self.Fva_in,self.Fvb_in,self.Fvc_in,self.Fvd_in,self.Fla_in,self.Flb_in,self.Flc_in,self.Fld_in,self.Tvin)[0]
        self.Hl_in=self.Htot(self.Fva_in,self.Fvb_in,self.Fvc_in,self.Fvd_in,self.Fla_in,self.Flb_in,self.Flc_in,self.Fld_in,self.Tlin)[1]
    
         #vapour entering from down which is position 0 and liquid entering from top so position 1
         
         
         
         
        #total enthalpy guess
        self.Hvguess=sc.ones(n)*self.Hv_in
        self.Hlguess=sc.ones(n)*self.Hl_in
        self.Fvaguess=sc.ones(n)*self.Fva_in #setting an array of ones
        self.Fvbguess=sc.ones(n)*self.Fvb_in
        self.Fvcguess=sc.ones(n)*self.Fvc_in
        self.Fvdguess=sc.ones(n)*self.Fvd_in
        self.Flaguess=sc.ones(n)*self.Fla_in
        self.Flbguess=sc.ones(n)*self.Flb_in
        self.Flcguess=sc.ones(n)*self.Flc_in
        self.Fldguess=sc.ones(n)*self.Fld_in
        
    def Htot(self,Fva,Fvb,Fvc,Fvd,Fla,Flb,Flc,Fld,T):     #total enthalpy
        a=self.a
        b=self.b
        c=self.c
        d=self.d
        Hv=Fva*a.Hv(T)+Fvb*b.Hv(T)+Fvc*c.Hv(T)+Fvd*b.Hv(T)
        Hl=Fla*a.Hl2(T)+Flb*b.Hl2(T)+Flc*c.Hl2(T)+Fld*d.Hl1(T,d.props.Tsat)
        return Hv,Hl
        
    def solve(self):
        guess=self.guess
        soln=opt.leastsq(residuals,guess,args=(self))[0]
   
    def residuals(guess,obj):
    n=obj.n
    dx=obj.dx
    P=obj.P
    a=obj.a
    b=obj.b
    c=obj.c
    d=obj.d
    Hv=guess[0:n]
    Hl=guess[n:2*n]
    Fva=guess[2*n:3*n]
    Fvb=guess[3*n:4*n]
    Fvc=guess[4*n:5*n]
    Fvd=guess[5*n:6*n]
    Fla=guess[6*n:7*n]
    Flb=guess[7*n:8*n]
    Flc=guess[8*n:9*n]
    Fld=guess[9*n:10*n]
    S=obj.S
    
    Fva[0]=obj.Fva_in
    Fvb[0]=obj.Fvb_in
    Fvc[0]=obj.Fvc_in
    Fvd[0]=obj.Fvd_in
    Fla[-1]=obj.Fla_in
    Flb[-1]=obj.Flb_in
    Flc[-1]=obj.Flc_in
    Fld[-1]=obj.Fld_in
    
    #First point and last point
     
    Ra_num=sc.ones(n)
    Ra_den=sc.ones(n)
    ErrFva=sc.ones(n)
    ErrFla=sc.ones(n)
    
    Ra_num[0]=(((P*Fva[0]/(Fva[0]+Fvb[0]+Fvc[0]+Fvd[0]))/((a.props.kH(T[0])))-(Fla[0]*a.props.rho/(Fla[0]+Flb[0]+Flc[0]+Fld[0]))
    Ra_den[0]=(1/((a.props.kH(T[0])*a.kga)))+(1/a.kla)
    ErrFva[0]=((Fva[1]-Fva[0])/dx)+(S*(Ra_num[0])/(Ra_den[0]))
    ErrFla[0]=((Fla[1]-Fla[0])/dx)+(S*(Ra_num[0])/Ra_den[0])
    
    Ra_num[-1]=(((P*Fva[-1]/(Fva[-1]+Fvb[-1]+Fvc[-1]+Fvd[-1]))/((a.props.kH(T[-1])))-(Fla[-1]*a.props.rho/(Fla[-1]+Flb[-1]+Flc[-1]+Fld[-1]))
    Ra_den[-1]=(1/((a.props.kH(T[-1])*a.kga)))+(1/a.kla)
    ErrFva[-1]=((Fva[-1]-Fva[-2])/dx)+(S*(Ra_num[-1])/(Ra_den[-1]))
    ErrFla[-1]=((Fla[-1]-Fla[-2])/dx)+(S*(Ra_num[-1])/Ra_den[-1])
    
    
    Rb_num=sc.zeros(n)
    Rb_den=sc.zeros(n)
    Rb_num[0]=(((P*Fvb[0]/(Fva[0]+Fvb[0]+Fvc[0]+Fvd[0]))/(b.props.kH(T[0])))-(Flb[0]*b.props.rho/(Fla[0]+Flb[0]+Flc[0]+Fld[0])))
    Rb_den[0]=(1/((b.props.kH(T[0])*b.kga)))+(1/b.kla)
    ErrFvb=sc.zeros(n)
    ErrFlb=sc.zeros(n)
    ErrFvb[0]=((Fvb[1]-Fvb[0])/dx)+(S*Rb_num[0]/Rb_den[0])
    ErrFlb[0]=((Flb[1]-Flb[0])/dx)+(S*Rb_num[0]/Rb_den[0])
    Rb_num[-1]=(((P*Fvb[-1]/(Fva[-1]+Fvb[-1]+Fvc[-1]+Fvd[-1]))/(b.props.kH(T[-1])))-(Flb[-1]*b.props.rho/(Fla[-1]+Flb[-1]+Flc[-1]+Fld[-1])))
    Rb_den[-1]=(1/((b.props.kH(T[-1])*b.kga)))+(1/b.kla)
    ErrFvb[-1]=((Fvb[-1]-Fvb[-2])/dx)+(S*Rb_num[-1]/Rb_den[-1])
    ErrFlb[-1]=((Flb[-1]-Flb[-2])/dx)+(S*Rb_num[-1]/Rb_den[-1])
    
    Rc_num=sc.zeros(n)
    Rc_den=sc.zeros(n)
    Rc_num[0]=(((P*Fvc[0]/(Fva[0]+Fvb[0]+Fvc[0]+Fvd[0]))/(c.props.kH(T[0])))-(Flc[0]*c.props.rho/(Fla[0]+Flb[0]+Flc[0]+Fld[0])))
    Rc_den[0]=(1/((c.props.kH(T[0])*c.kga)))+(1/c.kla)
    ErrFvc=sc.zeros(n)
    ErrFlc=sc.zeros(n)
    ErrFvc[0]=((Fvc[1]-Fvc[0])/dx)+(S*Rc_num[0]/Rc_den[0])
    ErrFlc[0]=((Flc[1]-Flc[0])/dx)+(S*Rc_num[0]/Rc_den[0])
    Rc_num[-1]=(((P*Fvc[-1]/(Fva[-1]+Fvb[-1]+Fvc[-1]+Fvd[-1]))/(c.props.kH(T[-1])))-(Flc[-1]*c.props.rho/(Fla[-1]+Flb[-1]+Flc[-1]+Fld[-1])))
    Rc_den[-1]=(1/((c.props.kH(T[-1])*c.kga)))+(1/c.kla)
    ErrFvc[-1]=((Fvc[-1]-Fvc[-2])/dx)+(S*Rc_num[-1]/Rc_den[-1])
    ErrFlc[-1]=((Flc[-1]-Flc[-2])/dx)+(S*Rc_num[-1]/Rc_den[-1])
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    """middle"""
    
 
    for i in range (1,n-1):
        
    Ra_num=sc.ones(n)
    Ra_den=sc.ones(n)
    ErrFva=sc.ones(n)
    ErrFla=sc.ones(n)
        
    Ra_num[i]=(((P*Fva[i]/(Fva[i]+Fvb[i]+Fvc[i]+Fvd[i]))/((a.props.kH(T[i])))-(Fla[i]*a.props.rho/(Fla[i]+Flb[i]+Flc[i]+Fld[i]))
    Ra_den[i]=(1/((a.props.kH(T[i])*a.kga)))+(1/a.kla)
    ErrFva[i]=((Fva[i+1]-Fva[i]*2+Fva[i-1])/(dx**2))+(S*(Ra_num[i])/(Ra_den[i]))
    ErrFla[i]=((Fla[i+1]-Fla[i]*2+Fva[i-1])/(dx**2))+(S*(Ra_num[i])/Ra_den[i])
    
   
        
        
        
        
        
a=fluid.Fluid(CH4)
b=fluid.Fluid(CO2)
c=fluid.Fluid(H2S)
d=fluid.Fluid(water)

Abs=Abs(a,b,c,d)      
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        