# -*- coding: utf-8 -*-
"""
Created on Wed Mar 11 13:47:06 2015

@author: vhd
"""
import Process_Simulation 
import Process_Simulation.Compounds.water as water
import Process_Simulation.Compounds.methane as CH4
import Process_Simulation.Compounds.carbondioxide as CO2
import Process_Simulation.Compounds.H2S as H2S
import Process_Simulation.fluid.fluid as fluid
import Abs


a=fluid.Fluid(CH4)
b=fluid.Fluid(CO2)
c=fluid.Fluid(H2S)
d=fluid.Fluid(water)

Abs=Abs.Abs(a,b,c,d)



