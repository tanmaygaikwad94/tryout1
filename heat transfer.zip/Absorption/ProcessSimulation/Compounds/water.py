# -*- coding: utf-8 -*-
"""
Created on Wed Jan 28 17:02:52 2015

@author: vhd
"""
import scipy as sc
import numpy as np


#Water
MW=18.015
Tc=647.096 #K
Pc=22.064e6 #pa
Zc=0.229
acc=0.3449


#water
Hf=-24.1814e7 #J/kmol
Gf=-22.859e7 #J/kmol
Tf=298.15 #K
Pf=101325 #Pa  
Tsat=373.15 #K



def Psat(T):
    C1=73.649;C2=-7258.2;C3=-7.3037;C4=4.1653*10**-6;C5=2
    #WATER P=Pa T=K
    Psat=sc.exp(C1+(C2/T)+(C3*sc.log(T))+(C4*T**C5))
    return Psat
    
def dens(T): #water 
    x=1-(T/647.096)
    rho=17.863+58.606*(x**0.35)-95.396*(x**2/3)+213.89*x-141.26*(x**(4/3)) #kmol/m3
    return rho
    
def Hv(T):
    Tc=647.096
    Tr=T/Tc  # hv=J/kmol T,Tc =K
    C1=5.2053*10**7;C2=0.3199;C3=-0.212;C4=0.25795;C5=0 #water
    Hv=C1*(1-Tr)**(C2+(C3*Tr)+(C4*Tr**2)+(C5*Tr**3))
    return Hv
    
def CpL(T):
    #Cp=J/kmol k , T=K
    C1=276370;C2=-2090.1;C3=8.125;C4=-0.014116;C5=9.3701*10**-6 #water
    CpL=C1+(C2*T)+(C3*T**2)+(C4*T**3)+(C5*T**4)
    return CpL
    
def CpG(T): #J/(kmol K)
    C1=0.3336*10**5;C2=0.2679*10**5;C3=2.6015*10**3;C4=0.08896*10**5;C5=1169
    cpg=C1+C2*(((C3/T)/(np.sinh(C3/T)))**2)+C4*((C5/T)/(np.cosh(C5/T)))**2
    return cpg
    
def viscL(T):  #Pa-s
    c1=-52.843;c2=3703.6;c3=5.866;c4=-5.879*10**-29;c5=10 
    mu=sc.exp(c1+(c2/T)+c3*sc.log(T)+c4*(T**c5))
    return mu

def viscG(T):  #Pa-s
    C1=1.7096E-8;C2=1.1146;C3=0;C4=0 #benzene
    mu=((C1*(T**C2))/(1+(C3/T)+(C4/T**2)))  
    return mu
    
def kv(T):
    c1=6.2041*10**-6; c2=1.3973
    kv=c1*T**c2
    return kv

def kl(T):
    c1=-0.432;c2=0.0057255;c3=-0.000008078;c4=1.861*10**-9
    kl=c1+c2*T+c3*T**2+c4*T**3
    return kl    
