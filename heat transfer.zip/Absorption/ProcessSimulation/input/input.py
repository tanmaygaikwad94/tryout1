# -*- coding: utf-8 -*-
"""
Created on Tue Mar 17 00:46:16 2015

@author: shilpa
"""

import scipy as sc

L=5 #m
D=0.5 #m
P=101325 #Pa
n=10 #gridsize
Tvin=303.15 #K
Tlin=303.15 #K

Fvin=100 #kmol/s
"""" given mol% """
cc=0.5*Fvin
Fvb_in=0.45*Fvin
Fvc_in=0.05*Fvin
Fvd_in=0.0*Fvin #no water in inlet gas

Flin=1000 #kmol/s

Fla_in=0.0*Flin
Flb_in=0.5*Flin
Flc_in=0.0*Flin
Fld_in=Flin #pure water as inlet.

#calculating area 
S=(sc.pi*D**2)/4




"""a=methane CH4  
   b=Carbon dioxide CO2
   c=hydrogen sulphide H2S
   d=water H2O"""
   







   




