# -*- coding: utf-8 -*-
"""
Created on Tue Mar 17 00:47:34 2015

@author: R014Tx
"""

import scipy  as sc
import scipy.optimize 
from scipy.interpolate import UnivariateSpline as uv
import scipy.integrate as integ
from scipy.integrate import quad

class Fluid:
    def __init__(self,fluidproperties):
        self.props=fluidproperties
        
    def kla():
        kla=0.001 # some model for kla will be given
        return kla
    
    def kga():
        kga=0.1 
        return kga
        
        
    def Hlv(self,T,P,Tsat):
        p=self.props
        
     
