# -*- coding: utf-8 -*-
"""
Created on Mon Mar 16 23:38:54 2015

@author: Shilpa
"""

import ProcessSimulation 
import ProcessSimulation.Compounds.water as water
import ProcessSimulation.Compounds.methane as CH4
import ProcessSimulation.Compounds.carbondioxide as CO2
import ProcessSimulation.Compounds.H2S as H2S
import ProcessSimulation.fluid.fluid as fluid
import Abs


a=fluid.Fluid(CH4) #class name is capital letter
b=fluid.Fluid(CO2)
c=fluid.Fluid(H2S)
d=fluid.Fluid(water)

Abs=Abs.Abs(a,b,c,d)
