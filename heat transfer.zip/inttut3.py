# -*- coding: utf-8 -*-
"""
Created on Tue Jan 20 12:02:56 2015

@author: vhd
"""

"""from scipy import integrate
mh=1 
mc=2
Thin=373.15 
Tcin=303.15
Thout=343.59
Tcout=318.09
Th1= lambda T:(4.184+(10**-9)*(T**3)+(10**-6)*(T**2)+(10**-4)*T)*1000
x=integrate.quad(Th1,Thin,Thout)
print x
Tc1= lambda T:(4.184+(10**-9)*(T**3)+(10**-6)*(T**2)+(10**-4)*T)*1000
y=integrate.quad(Tc1,Tcin,Tcout)
print y
z=mh*x+mc*y
print z"""

from scipy import integrate
def Cp(T):
    Cp=(4.184+(10**-9)*(T**3)+(10**-6)*(T**2)+(10**-4)*T)*1000
    return Cp

x=integrate.quad(Cp,303.15,343.16)
print x

    