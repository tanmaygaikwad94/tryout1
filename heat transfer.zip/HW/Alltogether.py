# -*- coding: utf-8 -*-
"""
Created on Sun Feb 15 19:15:32 2015

@author: Sonal
"""
import scipy
from matplotlib import pyplot
from Hex.ProcessSimulation.Compounds import Water,Benzene
from Hex.Chex import CHex
Chex1=CHex(Water,Benzene)
Chex1.grid()
Chex1.solve()
a_H=Chex1.Hsoln[:Chex1.n]
p_H=Chex1.Hsoln[Chex1.n:]
a_T=Chex1.T[:Chex1.n]
p_T=Chex1.T[Chex1.n:]
x=scipy.ones(Chex1.n)
x[0]=0
for i in range (1,Chex1.n):
    x[i]=x[i-1]+Chex1.dx
fig=pyplot.figure()
ax= fig.add_subplot(111); fig.show()
ax.plot(x,a_H,'r',x,p_H,'b')
fig1=pyplot.figure()
ax1=fig1.add_subplot(111); fig1.show()
ax1.plot(x,a_T,'r',x,p_T,'b')
