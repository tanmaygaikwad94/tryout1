# -*- coding: utf-8 -*-
"""
Created on Tue Feb 10 10:57:56 2015

@author: vhd
"""
import scipy as sp
from scipy.interpolate import UnivariateSpline
from scipy import integrate
from ProcessSimulation.Compounds import Water,Benzene
T=sp.linspace(303.16,373.16,30)
T1=sp.linspace(373.16,443.16,30)
T2=sp.linspace(303.16,353.26,30)
T3=sp.linspace(353.26,443.16,30)
Hvap_w=sp.ones(len(T1))
Hvap_b=sp.ones(len(T3))
Psat_w=sp.ones(len(T))
Psat_b=sp.ones(len(T2))
Hliq_w=sp.ones(len(T))
Hliq_b=sp.ones(len(T2))
for t in range(0,len(T)):
    Psat_w[t]=Water.Psat(T[t])    
    Hliq_w[t]=sp.integrate.quad(Water.CpG,298.15,T[t])[0]+Water.Hf-Water.Hvap(373.16)
for t in range(0,len(T2)):
    Hliq_b[t]=sp.integrate.quad(Benzene.CpG,298.15,T2[t])[0]+Benzene.Hf-Benzene.Hvap(353.26)
    Psat_b[t]=Benzene.Psat(T2[t])
for t in range(0,len(T1)):
    Hvap_w[t]=sp.integrate.quad(Water.CpG,298.16,T1[t])[0]+Water.Hf
for t in range(0,len(T3)):    
    Hvap_b[t]=sp.integrate.quad(Benzene.CpG,298.16,T3[t])[0]+Benzene.Hf
T_Psat_w=sp.interpolate.UnivariateSpline(Psat_w,T,k=1,s=0)
T_Psat_b=sp.interpolate.UnivariateSpline(Psat_b,T2,k=1,s=0)
T_Hvap_w=sp.interpolate.UnivariateSpline(Hvap_w,T1,k=1,s=0)
T_Hvap_b=sp.interpolate.UnivariateSpline(Hvap_b,T3,k=1,s=0)
T_Hliq_w=sp.interpolate.UnivariateSpline(Hliq_w,T,k=1,s=0)
T_Hliq_b=sp.interpolate.UnivariateSpline(Hliq_b,T2,k=5,s=0)

Do=10
Di=5
m_a=1
m_p=2
a_Tin=120+273.16
p_Tin=30+273.16
n=10
pressure=1.01325*10**5
Kv_w=0.016
Kl_w=0.58
Kv_b=0.127
Kl_b=0.144
L=500
A=500
