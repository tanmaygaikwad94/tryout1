# -*- coding: utf-8 -*-
"""
Created on Sat Jan 31 00:30:22 2015

@author: Sonal
"""

#Water-Physical and Chemical Properties
import scipy
Tc=647.096       #K
Pc=22.064E+06    #Pa
acc=0.3449
Zc=0.229
Vc=0.0559472        #m3/kmol
Hf=-24.1814*10**7 #J/Kmol
Gf=-22.859E+04    #J/mol
Sf=1.88724E+02   #J/mol K
Tf=25+273.16
Tb_1_atm=273.16+100           #k
Pf=1            #Pa
MW=18.015      #kg/kmol
def CpL(T):     #J/kmol-K
    c1=276370
    c2=-2090.1
    c3=8.125
    c4=-0.014116
    c5=9.3701E-06
    return (c1+c2*T+(c3*(T**2))+(c4*(T**3))+(c5*(T**4)))
def CpG(T):     #J/kmol-K
    c1=0.33363E+05
    c2=0.2679E+05
    c3=2.6105E+03
    c4=0.08896E+05
    c5=1169
    return  (c1+c2*((c3/T)/((scipy.sinh(c3/T))**2))+c4*((c5/T)/((scipy.cosh(c5/T))**2)))
def Hvap(T):    #J/kmol
    c1=5.2053E+07
    c2=0.3199
    c3=-0.212
    c4=-0.25795
    c5=0
    Tc=562.05
    Tr=T/Tc
    return (c1*(1-Tr)**(c2+(c3*Tr)+(c4*(Tr**2))+(c5*(Tr**3))))
def dens(T):    #kmol/m3
    c1=-13.851
    c2=0.64038
    c3=-0.00191
    c4=1.8211E-06
    return (c1+c2*T+c3*(T**2)+c4*(T**3))
def viscL(T):
    return 0.001    #Pa-s
def densG(T,P):
    R=8314.472      #J/kmol K
    return (P/(R*T))  #kmol/m3
def viscG(T):
    return 1E-0     #Pa-s
def Psat(T):        #Pa
    c1=73.649
    c2=-7258.2
    c3=-7.3037
    c4=4.1653E-06
    c5=2
    return scipy.exp(c1+(c2/T)+c3*scipy.log(T)+c4*(T**c5))
  


"""for t in range (1,10):
    y(t)=Psat(T(t))
    print y(t)
"""    