# -*- coding: utf-8 -*-
"""
Created on Fri Jan 30 23:53:00 2015

@author: Sonal
"""
#Benzene-Physical and Chemical Properties
import scipy
Tc=562.05       #K
Pc=4.895E+06    #Pa
acc=0.2103
Zc=0.268
Vc=0.256        #m3/kmol
Hf=8.288*10**7    #J/kmol
Gf=12.96E+04    #J/mol
Sf=2.6963E+02   #J/mol K
Tf=273.16+25
Tb_1_atm=273.16+80.1         #k
Pf=1            #Pa
MW=78.112       #kg/kmol
def CpL(T):     #J/kmol-K
    c1=129.440
    c2=-169.5
    c3=0.64781
    c4=0
    c5=0
    return (c1+c2*T+(c3*(T**2))+(c4*(T**3))+(c5*(T**4)))
def CpG(T):     #J/kmol-K
    c1=0.44767E+05
    c2=2.3085E+05
    c3=1.4792E+03
    c4=1.6836E+05
    c5=677.66
    return  (c1+c2*((c3/T)/((scipy.sinh(c3/T))**2))+c4*((c5/T)/((scipy.cosh(c5/T))**2)))
def Hvap(T):    #J/kmol
    c1=4.5345E+07
    c2=0.39053
    c3=0
    c4=0
    c5=0
    Tc=562.05
    Tr=T/Tc
    return (c1*(1-Tr)**(c2+(c3*Tr)+(c4*(Tr**2))+(c5*(Tr**3))))
def dens(T):    #kmol/m3
    c1=1.0259
    c2=0.2666
    c3=562.05
    c4=0.28394
    c5=0
    return (c1/(c2**(1+(1-((T/c3)**c4)))))
def viscL(T):
    return 0.001    #Pa-s
def densG(T,P):
    R=8314.472      #J/kmol K
    return (P/(R*T))  #kmol/m3
def viscG(T):
    return 1E-0     #Pa-s
def Psat(T):        #Pa
    c1=83.107
    c2=-6486.2
    c3=-9.2194
    c4=6.9844E-06
    c5=2
    return scipy.exp(c1+(c2/T)+c3*scipy.log(T)+c4*(T**c5))
    