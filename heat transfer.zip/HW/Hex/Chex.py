# -*- coding: utf-8 -*-
"""
Created on Sun Feb 15 11:52:52 2015

@author: Sonal
"""
from ProcessSimulation.Compounds import Water,Benzene
import Data
import scipy as sp
from scipy.optimize import leastsq
class CHex:
    def __init__(self,fl_annulus,fl_pipe):
        self.a_cp_l=fl_annulus.CpL
        self.p_cp_l=fl_pipe.CpL
        self.a_cp_g=fl_annulus.CpG
        self.p_cp_g=fl_pipe.CpG
        self.Do=Data.Do
        self.Di=Data.Di
        self.n=Data.n
        self.m_a=Data.m_a
        self.m_p=Data.m_p
        self.L=Data.L
        self.A=Data.A
        self.a_Tin=Data.a_Tin
        self.p_Tin=Data.p_Tin
        self.tb_a=fl_annulus.Tb_1_atm
        self.tb_p=fl_pipe.Tb_1_atm
        self.a_Hf=fl_annulus.Hf
        self.p_Hf=fl_pipe.Hf
        self.a_Hvap=fl_annulus.Hvap
        self.p_Hvap=fl_pipe.Hvap
    def grid(self):
        if (self.a_Tin<self.tb_a):
            self.H_a_in=sp.integrate.quad(self.a_cp_g,298.15,self.a_Tin)[0]+self.a_Hf-self.a_Hvap(self.tb_a)
        else:
            self.H_a_in=sp.integrate.quad(self.a_cp_g,298.15,self.a_Tin)[0]+self.a_Hf
        if (self.p_Tin<self.tb_p):
            self.H_p_in=sp.integrate.quad(self.p_cp_g,298.15,self.p_Tin)[0]+self.p_Hf-self.p_Hvap(self.tb_p)
        else:
            self.H_p_in=sp.integrate.quad(self.p_cp_g,298.15,self.p_Tin)[0]+self.p_Hf
        self.H_a=sp.ones(self.n)*self.H_a_in
        self.H_p=sp.ones(self.n)*self.H_p_in
        self.Af_a=float((sp.pi/4)*(self.Do**2-self.Di**2))
        self.Af_p=float((sp.pi/4)*(self.Di-.05)**2)
        self.dx=float(self.L)/(self.n-1)
        self.dA=self.A/(self.n-1)#float(sp.pi*self.dx*self.Di)
        self.Hguess=sp.concatenate((self.H_a,self.H_p))
        
    def solve(self):
        Hguess=self.Hguess
        self.Hsoln1=sp.optimize.leastsq(residuals,Hguess,args=(self))
        self.Hsoln=self.Hsoln1[0]
        self.H_a=self.Hsoln[:self.n]
        self.H_p=self.Hsoln[self.n:]
        self.a_fv=sp.ones(self.n)
        self.p_fv=sp.ones(self.n)
        self.a_T=sp.ones(self.n)
        self.p_T=sp.ones(self.n)
        self.pressure=Data.pressure
        self.T_sat_w=Data.T_Psat_w(self.pressure)
        self.T_sat_b=Data.T_Psat_b(self.pressure)
        self.a_H_sat_l=sp.integrate.quad(self.a_cp_g,298.15,self.T_sat_w)[0]+self.a_Hf-self.a_Hvap(self.T_sat_w)
        self.p_H_sat_l=sp.integrate.quad(self.p_cp_g,298.15,self.T_sat_b)[0]+self.p_Hf-self.p_Hvap(self.T_sat_b)
        self.a_H_sat_g=sp.integrate.quad(self.a_cp_g,298.15,self.T_sat_w)[0]+self.a_Hf
        self.p_H_sat_g=sp.integrate.quad(self.p_cp_g,298.15,self.T_sat_b)[0]+self.p_Hf
        for i in range(0,self.n):
            if self.H_a[i]<=self.a_H_sat_l:
                self.a_fv[i]=0
                self.a_T[i]=Data.T_Hliq_w(self.H_a[i])
            elif self.H_a[i]>=self.a_H_sat_g:
                self.a_fv[i]=1
                self.a_T[i]=Data.T_Hvap_w(self.H_a[i])
            else:
                self.a_fv[i]=(self.H_a[i]-self.a_H_sat_l)/(self.a_H_sat_g-self.a_H_sat_l)
                self.a_T[i]=self.T_sat_w
            if self.H_p[i]<self.p_H_sat_l:
                self.p_fv[i]=0
                self.p_T[i]=Data.T_Hliq_b(self.H_p[i])
            elif self.H_p[i]>self.p_H_sat_g:
                self.p_fv[i]=1
                self.p_T[i]=Data.T_Hvap_b(self.H_p[i])
            else:
                self.p_fv[i]=(self.H_p[i]-self.p_H_sat_l)/(self.p_H_sat_g-self.p_H_sat_l)
                self.p_T[i]=self.T_sat_b
        self.T=sp.concatenate((self.a_T,self.p_T))        
        return self.T,self.Hsoln
n=Data.n            
a_fv=sp.ones(n)
p_fv=sp.ones(n)
a_T=sp.ones(n)
p_T=sp.ones(n)
U=sp.ones(n)

a_k=sp.ones(n)
p_k=sp.ones(n)            
            
def residuals(H,obj):
    n=obj.n
    H_a=H[:n]
    H_p=H[n:]
    dA=obj.dA
    Af_a=obj.Af_a
    Af_p=obj.Af_p
    dx=obj.dx
    m_a=obj.m_a
    m_p=obj.m_p
    pressure=Data.pressure
    T_sat_w=Data.T_Psat_w(pressure)
    T_sat_b=Data.T_Psat_b(pressure)
    Hf_a=obj.a_Hf
    Hf_p=obj.p_Hf
    H_a[0]=obj.H_a_in
    print "H_a"
    print H_a
    H_p[-1]=obj.H_p_in
    print "H_p"
    print H_p
    cp_a_g=obj.a_cp_g
    cp_p_g=obj.p_cp_g
    p_Hvap=obj.p_Hvap
    a_Hvap=obj.a_Hvap
    a_H_sat_l=sp.integrate.quad(cp_a_g,298.15,T_sat_w)[0]+Hf_a-a_Hvap(T_sat_w)
    p_H_sat_l=sp.integrate.quad(cp_p_g,298.15,T_sat_b)[0]+Hf_p-p_Hvap(T_sat_b)
    a_H_sat_g=sp.integrate.quad(cp_a_g,298.15,T_sat_w)[0]+Hf_a
    p_H_sat_g=sp.integrate.quad(cp_p_g,298.15,T_sat_b)[0]+Hf_p
    
    err_p=sp.ones(n)
    err_a=sp.ones(n)
    for i in range(0,n):
        if H_a[i]<a_H_sat_l:
            a_fv[i]=0
            a_T[i]=Data.T_Hliq_w(H_a[i])
        elif H_a[i]>a_H_sat_g:
            a_fv[i]=1
            a_T[i]=Data.T_Hvap_w(H_a[i])
        else:
            a_fv[i]=(H_a[i]-a_H_sat_l)/(a_H_sat_g-a_H_sat_l)
            a_T[i]=T_sat_w 
        if H_p[i]<p_H_sat_l:
            p_fv[i]=0
            p_T[i]=Data.T_Hliq_b(H_p[i])
        elif H_p[i]>p_H_sat_g:
            p_fv[i]=1
            p_T[i]=Data.T_Hvap_b(H_p[i])
        else:
            p_fv[i]=(H_p[i]-p_H_sat_l)/(p_H_sat_g-p_H_sat_l)
            p_T[i]=T_sat_b 
        a_k[i]=a_fv[i]*Data.Kv_w+(1-a_fv[i])*Data.Kl_w
        p_k[i]=p_fv[i]*Data.Kv_b+(1-p_fv[i])*Data.Kl_b
        if a_fv[i]==0 and p_fv[i]==0:
            U[i]=500
        elif (a_fv[i]>0 and a_fv[i]<1) and (p_fv[i]>0 and p_fv[i]<1):
            U[i]=1000
        elif a_fv[i]==1 and p_fv[i]==1:
            U[i]=1000
        elif (a_fv[i]==1 or p_fv[i]==1) and (a_fv[i]!=p_fv[i]):
            U[i]=100
        elif ((a_fv[i]>0 and a_fv[i]<1) or (p_fv[i]>0 and p_fv[i]<1)) and not ((a_fv[i]>0 and a_fv[i]<1) and (p_fv[i]>0 and p_fv[i]<1)):
            U[i]=100
        
        #print "a_T,a_fv"
        #print a_T, a_fv
        print "p_T,p_fv"
        print p_T, a_fv

    err_p[0]=Af_p*p_k[0]*((p_T[2]-p_T[1]*2+p_T[0])/dx**2)+Af_p*((p_T[1]-p_T[0])/dx)*((p_k[1]-p_k[0])/dx)+m_p*(H_p[1]-H_p[0])/dx+dA*(a_T[0]-p_T[0])*(U[0])/dx  
    err_a[0]=Af_a*a_k[0]*((a_T[2]-a_T[1]*2+a_T[0])/dx**2)+Af_a*((a_T[1]-a_T[0])/dx)*((a_k[1]-a_k[0])/dx)-m_a*(H_a[1]-H_a[0])/dx-dA*(a_T[0]-p_T[0])*(U[0])/dx
    err_p[-1]=Af_p*p_k[-1]*((p_T[-1]-p_T[-2]*2+p_T[-3])/dx**2)+Af_p*((p_T[-1]-p_T[-2])/dx)*((p_k[-1]-p_k[-2])/dx)+m_p*(H_p[-1]-H_p[-2])/dx+dA*(a_T[-1]-p_T[-1])*(U[-1])/dx
    err_a[-1]=Af_a*a_k[-1]*((a_T[-1]-a_T[-2]*2+a_T[-3])/dx**2)+Af_a*((a_T[-1]-a_T[-2])/dx)*((a_k[-1]-a_k[-2])/dx)-m_a*(H_a[-1]-H_a[-2])/dx-dA*(a_T[-1]-p_T[-1])*(U[-1])/dx    
    for i in range (1,n-1):
        err_p[i]=Af_p*p_k[i]*((p_T[i+1]-p_T[i]*2+p_T[i-1])/(dx**2))+Af_p*((p_T[i+1]-p_T[i-1])/(2*dx))*((p_k[i+1]-p_k[i-1])/(2*dx))+m_p*(H_p[i+1]-H_p[i-1])/(2*dx)+dA*(a_T[i]-p_T[i])*(U[i])/(dx)
        err_a[i]=Af_a*a_k[i]*((a_T[i+1]-a_T[i]*2+a_T[i-1])/(dx**2))+Af_a*((a_T[i+1]-a_T[i-1])/(2*dx))*((a_k[i+1]-a_k[i-1])/(2*dx))-m_a*(H_a[i+1]-H_a[i-1])/(2*dx)-dA*(a_T[i]-p_T[i])*(U[i])/(dx)
    err=sp.concatenate((err_a,err_p))
    #print "err"
    #print err    
    return err      

    
    '''    err_p[1:-1]=Af_p*p_k[1:-1]*((p_T[2:]-p_T[1:-1]*2+p_T[:-2])/(dx**2))+Af_p*((p_T[2:]-p_T[:-2])/(2*dx))*((p_k[2:]-p_k[:-2])/(2*dx))+m_p*(H_p[2:]-H_p[:-2])/(2*dx)+dA*(a_T[1:-1]-p_T[1:-1])*(p_U[2:]-p_U[:-2])/(2*dx)
    err_a[1:-1]=Af_a*a_k[1:-1]*((a_T[2:]-a_T[1:-1]*2+a_T[:-2])/(dx**2))+Af_a*((a_T[2:]-a_T[:-2])/(2*dx))*((a_k[2:]-a_k[:-2])/(2*dx))-m_a*(H_a[2:]-H_a[:-2])/(2*dx)-dA*(a_T[1:-1]-p_T[1:-1])*(a_U[2:]-a_U[:-2])/(2*dx)    
    err=sp.concatenate((err_a,err_p))
    print "error"
        print err'''
    

'''Chex1=CHex(Water,Benzene)
Chex1.grid()
Chex1.solve()'''