# -*- coding: utf-8 -*-
"""
Created on Tue Feb 10 12:35:22 2015

@author: vhd
"""

import scipy as sc
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import UnivariateSpline
def f1(x):
    y=sc.log((3*(x**2)+(2*x)+4))
    return y
x=sc.linspace(0,100,1000)
fig=plt.figure()
ax=fig.add_subplot(111)
fig.show()
i=1
for i in range(1,100):
    y=f1(x)
    z=sc.interpolate.UnivariateSpline(y,x,k=3,s=0)
    ax.clear()
    ax.plot(y,z(y),'r')
    plt.pause(2)
i+=1
    