# -*- coding: utf-8 -*-
"""
Created on Tue Apr 07 03:59:24 2015

@author: R014Tx
"""
import scipy
kla=0.001  #/s
kga=1   #/s
P=101325  #Pa
rho=55.55 #kmol/m3
n=10
L=12
d=4
S=(scipy.pi/4)*(d**2)
Fv_co2_in=45
Fv_h2o_in=0
Fv_h2s_in=5
Fv_ch4_in=50
Fl_h2o_in=100
Fl_co2_in=0
Fl_h2s_in=0
Fl_ch4_in=0
Tin_ch4=300+273.16
Tin_h2s=300+273.16
Tin_co2=300+273.16
Tin_h2o=30+273.16
T_v=300+273.16
T_l=30+273.16