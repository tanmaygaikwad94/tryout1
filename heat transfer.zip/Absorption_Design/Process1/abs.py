# -*- coding: utf-8 -*-
"""
Created on Tue Apr 07 03:58:46 2015

@author: R014Tx
"""

import scipy 
import matplotlib.pyplot as plt
from scipy.optimize import leastsq
from scipy import integrate
import data
from Compounds import CO2,H2S,CH4,H2O


class Abs():
     def __init__(self):
        self.Fv_co2=data.Fv_co2_in
        self.Fv_h2o=data.Fv_h2o_in
        self.Fv_ch4=data.Fv_ch4_in
        self.Fv_h2s=data.Fv_h2s_in
        self.Fl_co2=data.Fl_co2_in
        self.Fl_h2o=data.Fl_h2o_in
        self.Fl_ch4=data.Fl_ch4_in
        self.Fl_h2s=data.Fl_h2s_in
        self.Tin_co2=data.Tin_co2
        self.Tin_h2o=data.Tin_h2o
        self.Tin_h2s=data.Tin_h2s
        self.Tin_ch4=data.Tin_ch4
        self.T_v=data.T_v
        self.T_l=data.T_l
        self.kla=data.kla
        self.kga=data.kga
        self.P=data.P
        self.n=data.n
        self.L=data.L
        self.d=data.d
        self.S=data.S
        self.rho=data.rho
        
def set_grid(self):
        #grid of initial guesses total 8 guesses 4 in liqd 4 in vapour
        
        """LIQUID"""
        self.Fl_co2=scipy.ones(self.n)*self.Fl_co2_in
        self.Fl_ch4=scipy.ones(self.n)*self.Fl_ch4_in
        self.Fl_h2o=scipy.ones(self.n)*self.Fl_h2o_in
        self.Fl_h2s=scipy.ones(self.n)*self.Fl_h2s_in
        """VAPOUR"""
        self.Fv_co2=scipy.ones(self.n)*self.Fv_co2_in        
        self.Fv_ch4=scipy.ones(self.n)*self.Fv_ch4_in
        self.Fv_h2o=scipy.ones(self.n)*self.Fv_h2o_in
        self.Fv_h2s=scipy.ones(self.n)*self.Fv_h2s_in
        
        
        #guess value for enthalpy
        """self.Hin_co2=self.Fv_co2_in*(scipy.integrate.quad(CO2.CpG,298.15,self.Tin_CO2)[0]+CO2.Hf)"""
        self.Hin_ch4=self.Fv_ch4_in*(scipy.integrate.quad(CH4.CpG,298.15,self.Tin_CH4)[0]+CH4.Hf)
        """self.Hin_h2s=self.Fv_h2s_in*(scipy.integrate.quad(H2S.CpG,298.15,self.Tin_H2S)[0]+H2S.Hf)
        self.Hin_h2o=self.Fv_h20_in*(scipy.integrate.quad(H2O.CpG,298.15,self.Tin_H2O)[0]+H2O.Hf-H2O.Hv(H2O.Tb))"""
        
        self.H_v=scipy.ones(self.n)*self.Hin_CH4
        self.H_l=scipy.ones(self.n)*self.Hin_CH4        
        
         #guess values for Temp
        self.T=scipy.ones(self.n)*self.T_v
        self.dz=self.L/float(self.n-1)
        
         #concatenate all ur guesses
        self.F_guess=scipy.concatenate((self.Fl_h2o,self.Fl_h2s,self.Fl_co2,self.Fl_ch4,self.Fv_ch4,self.Fv_h2o,self.Fv_h2s,self.Fv_co2,self.T))

def solve(self):
        F_guess=self.F_guess
        self.F_soln=scipy.optimize.leastsq(residuals,F_guess,args=(self))[0]
        
        self.Fl_h2o=self.F_soln[:self.n]
        self.Fl_h2s=self.F_soln[self.n:2*self.n]
        self.Fl_co2=self.F_soln[2*self.n:3*self.n]
        self.Fl_ch4=self.F_soln[3*self.n:4*self.n]
        
        self.Fv_ch4=self.F_soln[4*self.n:5*self.n]
        self.Fv_h2o=self.F_soln[5*self.n:6*self.n]
        self.Fv_h2s=self.F_soln[6*self.n:7*self.n]
        self.Fv_co2=self.F_soln[7*self.n:8*self.n]

        self.T=self.F_soln[8*self.n:9*self.n]
        
        print "Fv_h2s"
        print self.Fv_h2s
        print "Fl_h2s"
        print self.Fl_h2s
        print "Fv_co2"
        print self.Fv_co2
        print "Fl_co2"
        print self.Fl_co2
        print "Fv_ch4"
        print self.Fv_ch4
        print "Fl_ch4"
        print self.Fl_ch4
        print "Fl_h2o"
        print self.Fl_h2o
        print "Fv_h2o"
        print self.Fv_h2o
        print "T"
        print self.T
        
def residuals(F,obj):
    kla=obj.kla
    kga=obj.kga
    P=obj.P
    n=obj.n
    L=obj.L
    dz=obj.dz
    d=obj.d
    S=obj.S
    rho=obj.rho
    T_v=obj.T_v
    Fv_co2_in=obj.Fv_co2_in
    Fv_h2s_in=obj.Fv_h2s_in
    Fv_ch4_in=obj.Fv_ch4_in
    Fv_h2o_in=obj.Fv_h2o_in
    Fl_co2_in=obj.Fl_co2_in
    Fl_h2s_in=obj.Fl_h2s_in
    Fl_ch4_in=obj.Fl_ch4_in
    Fl_h2o_in=obj.Fl_h2o_in
    Tin_co2=obj.Tin_co2
    Tin_h2o=obj.Tin_h2o
    Tin_h2s=obj.Tin_h2s
    Tin_ch4=obj.Tin_ch4
    
    
    
    #doing conc cal.
    
    Fl_h2o=F[:n]
    Fl_h2s=F[n:2*n]
    Fl_co2=F[2*n:3*n]
    Fl_ch4=F[3*n:4*n]
    
    Fv_ch4=F[4*n:5*n]
    Fv_h2o=F[5*n:6*n]
    Fv_h2s=F[6*n:7*n]
    Fv_co2=F[7*n:8*n]
    
    T=F[8*n:9*n]
    
    Fv=scipy.ones(n) #kmol/s
    Fl=scipy.ones(n)*100
    Fv_h2s[0]=5*Fv[0]
    Fv_ch4[0]=50*Fv[0]
    Fv_co2[0]=45*Fv[0]
    Fv_h2o[0]=0
    Fl_h2s[-1]=0
    Fl_co2[-1]=0
    Fl_ch4[-1]=0
    Fl_h2o[-1]=100
    
      #for storing errors
    err_h2s_v=scipy.ones(n)
    err_h2s_l=scipy.ones(n)
    err_co2_v=scipy.ones(n)
    err_co2_l=scipy.ones(n)
    err_ch4_v=scipy.ones(n)
    err_ch4_l=scipy.ones(n)
    err_h2o_v=scipy.ones(n)
    err_h2o_l=scipy.ones(n)
    
    T=scipy.ones(n)*T_v
    T[0]=300+273.16   
    T[-1]=30+273.16
    
    Fv_ch4out=Fv_ch4[-1]
    Fv_co2out=Fv_co2[-1]
    Fv_h2sout=Fv_h2s[-1]
    Fv_h2oout=Fv_h2o[-1]
    
    Fv=Fv_ch4+Fv_co2+Fv_h2s+Fv_h2o
    
    Fl=Fl_ch4+Fl_co2+Fl_h2s+Fl_h2o
    
    ych4=Fv_ch4/Fv
    yco2=Fv_co2/Fv
    yh2s=Fv_h2s/Fv
    yh2o=Fv_h2o/Fv
    
    xch4=Fl_ch4/Fl
    xco2=Fl_co2/Fl
    xh2s=Fl_h2s/Fl
    xh2o=Fl_h2o/Fl
    
    
    drv_ch4=P*ych4*Hen(T)-rho*xch4
    kch4=((1/kla)+(1/kga)*(1/Hen(T)))**(-1)
    
    drv_co2=P*yco2*Hen(T)-rho*xco2
    kco2=((1/kla)+(1/kga)*(1/Hen(T)))**(-1)
    
    drv_h2s=P*yh2s*Hen(T)-rho*xh2s
    kh2s=((1/kla)+(1/kga)*(1/Hen(T)))**(-1)
    
    drv_h2o=P*yh2o-Psat(T)
    kh2o=kga
    
    
    
    Rch4=drv_ch4*kch4
    Rco2=drv_co2*kco2
    Rh2s=drv_h2s*kh2s
    Rh2o=drv_h2o*kh2o
            
   
   df_ch4=np.gradient(Fv_ch4,dz)
   df_co2=np.gradient(Fv_co2,dz)
   df_h2s=np.gradient(Fv_h2s,dz)
   df_h2o=np.gradient(Fv_h2o,dz)
   
   
   
   err_ch4=df_ch4+Rch4*S
   err_co2=df_ch4+Rch4*S
   err_h2s=df_ch4+Rch4*S
   err_h2o=df_ch4+Rch4*S
























