import scipy as sc
import numpy as np


MW=16.042
Tc=190.2564 #K
Pc=4.599 #pa
Zc=0.286
acc=0.0115

Hf=-7.452e7 #J/kmol
Tf=298.15 #K

"""def Hv(T):
    Tc=190.2564
    Tr=T/Tc  # hv=J/kmol T,Tc =K
    C1=1.0194*10**7;C2=0.26087;C3=-0.14694;C4=0.22154;C5=0 
    Hv=C1*(1-Tr)**(C2+(C3*Tr)+(C4*Tr**2)+(C5*Tr**3))
    return Hv"""
    
def CpG(T): #J/(kmol K)
    C1=0.33298*10**5;C2=0.7993*10**5;C3=2.0869*10**3;C4=0.41602*10**5;C5=991.96
    cpg=C1+C2*(((C3/T)/(np.sinh(C3/T)))**2)+C4*((C5/T)/(np.cosh(C5/T)))**2
    return cpg 
    
     
def Hv(T):
    return Hf+sc.integrate.quad(CpG,Tf,T)[0]
    
def Hl(T):
    return Hv(T)-Habs 
    
def Hen(T):
    kHo=1.4e-3
    dH=1600 #dh/R in K
    kH=kHo*sc.exp(-dH*((1/T)-(1/298)))/101325 #mol/m3atm
    return 1/kH
    
Habs=1600*8314 #J/kmol