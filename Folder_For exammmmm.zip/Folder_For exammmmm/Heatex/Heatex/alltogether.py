# -*- coding: utf-8 -*-
"""
Created on Wed Jan 28 11:02:23 2015

@author: vhd
"""
import ProcessSimulation.Compounds.water as water
import ProcessSimulation.Compounds.benzene as benzene
import ProcessSimulation.Heatexchanger.equipment as equip
import ProcessSimulation.fluids.fluid as fluid
import scipy as sc
import scipy.optimize as opt
import matplotlib.pyplot as plt
import DPHex_H 
#import scipy as sc
#import matplotlib.pylab as plt
#
#import ProcessSimulation 
#
#from ProcessSimulation.Compounds import water,benzene
#
#from ProcessSimulation.fluids.fluid import Fluid
#from ProcessSimulation.Heatexchanger.DPHex import DPHex
#from ProcessSimulation.Heatexchanger import operatingcond 



#DPHex=DPHex(water,water)
#
#listn=sc.array([20*i for i in range(1,5)])
#listerr=[]
#for n in listn:
#    DPHex.set_grid(n)
#    DPHex.solve()
#    err=DPHex.check()
#    listerr += [err]
#print(listn)
#print(listerr)    
#plt.plot(listn,listerr)
#plt.show()
#
#
a=fluid.Fluid(water)
b=fluid.Fluid(benzene)    
DP=DPHex_H.DPHex(a,b)

x=DP.solve()

a1=range(0,100,10)
plt.plot(a1,DP.Tasoln[0],'r')
plt.show()
a1=range(0,100,10)
plt.plot(a1,DP.Tbsoln[0],'b')
plt.show()








