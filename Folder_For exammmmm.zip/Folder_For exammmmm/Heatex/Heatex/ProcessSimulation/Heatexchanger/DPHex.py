# -*- coding: utf-8 -*-
"""
Created on Wed Jan 28 09:53:59 2015

@author: vhd
"""

import scipy as sc
import scipy.optimize as opt
import scipy.integrate as integ
from scipy.integrate import quad
import matplotlib.pyplot as plt
import operatingcond as op

class DPHex:
    def __init__(self,flannulus,flpipe):
        self.u=op.u
        self.a=op.a
        self.mh=op.mh
        self.mc=op.mc
        self.Thin=op.Thin
        self.Tcin=op.Tcin
        self.n=op.n
        self.set_grid(op.n)
        self.cph=flannulus.CpL
        self.cpc=flpipe.CpL
        
        
        
    def set_grid(self,n):
        self.n=n
        self.da=self.a/(n-1)
        self.Th=sc.ones(n)*self.Thin
        self.Tc=sc.ones(n)*self.Tcin
        self.Tguess=sc.concatenate((self.Th,self.Tc))
    def solve(self):
        Tguess=self.Tguess
        Tsoln=opt.leastsq(residuals,Tguess,args=(self))[0]
        self.Th=Tsoln[:self.n]
        self.Tc=Tsoln[self.n:]
        self.Th[0]=self.Thin
        self.Tc[-1]=self.Tcin
        
    def check(self):
        (Hh,er1)=quad(self.cph,self.Th[-1],self.Th[0])
        
        (Hc,er2)=quad(self.cpc,self.Tc[-1],self.Tc[0])
        
        Err=self.mc*Hc-self.mh*Hh
        return Err

        
def residuals(T,obj):
    n=obj.n
    Th=T[:n]
    Tc=T[n:]
    Th[0]=obj.Thin
    Tc[-1]=obj.Tcin
    cph=obj.cph
    cpc=obj.cpc
    u=obj.u
    Thin=obj.Thin
    Tcin=obj.Tcin
    mh=obj.mh
    mc=obj.mc
    da=obj.da
    errHL=(u*(Thin-Tc[0])/(mh*cph(Thin)))+((Th[1]-Thin))/da
    errCL=(u*(Thin-Tc[0])/(mc*cpc(Tc[0])))+((Tc[1]-Tc[0]))/da
    errHR=(u*(Th[-1]-Tcin)/(mh*cph(Th[-1])))+((Th[-1]-Th[-2]))/da
    errCR=(u*(Th[-1]-Tcin)/(mc*cpc(Tcin)))+((Tcin-Tc[-2]))/da
    errH=sc.zeros(n)
    errC=sc.zeros(n)
    errH[0]=errHL
    errH[-1]=errHR
    errC[0]=errCL
    errC[-1]=errCR
    errH[1:-1]=(u*(Th[1:-1]-Tc[1:-1])/(mh*cph(Th[1:-1])))+(Th[2:]-Th[1:-1])/da
    errC[1:-1]=(u*(Th[1:-1]-Tc[1:-1])/(mc*cpc(Tc[1:-1])))+(Tc[2:]-Tc[1:-1])/da
    return sc.concatenate((errH,errC))
    
'''def ans():
    listn=sc.array([10**i for i in range(1,4)])
    listerr=[]
    for n in listn:
        hex1.set_grid(n)
        hex1.solve()
        err=hex1.check()
        listerr += [err]
        
    
    print(listerr)    
    plt.plot(listn,listerr)
    plt.show()'''
