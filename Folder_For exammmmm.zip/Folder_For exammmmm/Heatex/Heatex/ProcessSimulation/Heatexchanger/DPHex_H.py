# -*- coding: utf-8 -*-
"""
Created on Sun Feb 15 09:50:27 2015

@author: Girija
"""

import ProcessSimulation

#import ProcessSimulation.Compounds.benzene as benzene
#import ProcessSimulation.Heatexchanger.equipment as equip
#
#Tcin=equip.Tcin
#Thin=equip.Thin
#n=equip.n
#Tg=[Tcin]*n
#print Tg
#Tg[0]=Tcin
#for i in Tg:
#    Tg[i+1]=Tg[i]+10
    
