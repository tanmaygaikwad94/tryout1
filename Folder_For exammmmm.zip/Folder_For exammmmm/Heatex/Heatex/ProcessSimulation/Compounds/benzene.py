


import scipy as sc
import numpy as np

#benzene
MW=78.112
Tc=562.05 #K
Pc=4.895e6 #Pa
Zc=0.268
acc=0.2103
     
def Psat(T): 
    #P=Pa T=K
    C1=83.107;C2=-6486.2;C3=-9.2194;C4=6.9844*10**-6;C5=2
    Psat=sc.exp(C1+(C2/T)+(C3*sc.log(T))+(C4*T**C5))
    return Psat
    
def dens(T): #benzene
    c1=1.0259
    c2=0.2666
    c3=562.05
    c4=0.28394
    rho=c1/(c2**(1+(1-(T/c3)**c4))) #kmol/m3
    return rho

def Hv(T): #J/kmol
    Tc=562.05
    Tr=T/Tc  # hv=J/kmol T,Tc =K
    C1=4.5346e7;C2=0.39053;C3=0;C4=0;C5=0 #benz
    Hv=C1*(1-Tr)**(C2+(C3*Tr)+(C4*Tr**2)+(C5*Tr**3))
    return Hv   
    
def CpL(T):
    #Cp=J/kmol K , T=K
    C1=162940;C2=-344.94;C3=0.85562;C4=0;C5= 0
    CpL=C1+(C2*T)+(C3*T**2)+(C4*T**3)+(C5*T**4)
    return CpL  
    
def CpG(T): #J/(kmol K)
    C1=0.4476*10**5;C2=2.3085*10**5;C3=1.4792*10**3;C4=1.6836*10**5;C5=677.66
    cpg=C1+C2*(((C3/T)/(np.sinh(C3/T)))**2)+C4*((C5/T)/(np.cosh(C5/T)))**2
    return cpg
    
def viscL(T):  #Pa-s
    c1=7.5117;c2=294.68;c3=-2.798;c4=0;c5=0 
    mu=sc.exp(c1+(c2/T)+c3*sc.log(T)+c4*(T**c5))
    return mu
    

def viscG(T):  #Pa-s
    C1=3.134E-8;C2=0.9676;C3=7.9;C4=0 
    mu=((C1*(T**C2))/(1+(C3/T)+(C4/T**2)))  
    return mu
    
#benzene
Hf=8.288e7 #J/kmol
Gf=12.96e7 #J/kmol
Tf=298.15 #K
Pf=101325 #Pa
    
def kv(T):
    c1=0.00001652;c2=1.3117;c3=491
    kv=(c1*T**c2)/(1+(c3/T))
    return kv
    
def kl(T):
    c1=0.23444;c2=-0.00030572
    kl=c1+c2*T
    return kl
