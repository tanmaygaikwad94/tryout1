

import numpy as np
import scipy.interpolate as interp
import win32com.client
import scipy,os
import pandas
filename='Carbon Dioxide.xlsx'
thisdir=os.getcwd()
x1=win32com.client.gencache.EnsureDispatch("Excel.Application")
wb=x1.Workbooks.Open(thisdir + "/" + filename)
x1.Visible=True


sheet=wb.Sheets("Data")

'''P=np.hstack(np.array(sheet.Range('A2:A1090').Value))
T=np.hstack(np.array(sheet.Range('B2:B1090').Value))
H=np.hstack(np.array(sheet.Range('D2:D1090').Value))
S=np.hstack(np.array(sheet.Range('E2:E1090').Value))
Cp=np.hstack(np.array(sheet.Range('F2:F1090').Value))
Cv=np.hstack(np.array(sheet.Range('G2:G1090').Value))
rho=np.hstack(np.array(sheet.Range('C2:C1090').Value))
inter_s=interp.bisplrep(P,T,S)  
inter_h=interp.bisplrep(P,T,H) 
inter_cp=interp.bisplrep(P,T,Cp)
inter_cv=interp.bisplrep(P,T,Cv)''' 

if os.path.isdir("Data"):
    os.chdir("Data")
xl_file = pandas.ExcelFile(filename)
os.chdir(thisdir)
df = {}  #dataframe or dict of dataframe
df["Data"] = xl_file.parse("Data")
Temp=scipy.ones(1089)
Pres=scipy.ones(1089)
Enthalpy=scipy.ones(1089)
Entropy=scipy.ones(1089)
Dens=scipy.ones(1089)
Cp=scipy.ones(1089)
Cv=scipy.ones(1089)
#Water = xlrd.open_workbook("Water")
#data_sheet = Water.get_sheet(0) 
#rowcountWater = data_sheet.nrows
db=df["Data"]
for j in range(1,1089):
    Temp[j]=db.Temperature.values[j]
    Pres[j]=db.Pressure.values[j]
    Dens[j]=db.Density.values[j]
    Enthalpy[j]=db.Specific_Enthalpy.values[j]
    Entropy[j]=db.Specific_Entropy.values[j]
    Cp[j]=db.Cp.values[j]
    Cv[j]=db.Cv.values[j]
def enthalpy(T,P):
    Enthalinterp=scipy.interpolate.bisplrep(Temp,Pres,Enthalpy)
    Enthalnew=scipy.interpolate.bisplev(T,P,Enthalinterp)
    return Enthalnew
def entropy(T,P):
    Entropyinterp=scipy.interpolate.bisplrep(Temp,Pres,Entropy)
    Entropynew=scipy.interpolate.bisplev(T,P,Entropyinterp)
    return Entropynew 
    print Entropynew 