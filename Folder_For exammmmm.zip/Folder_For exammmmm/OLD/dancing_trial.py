# -*- coding: utf-8 -*-
"""
Created on Tue Jan 20 11:24:51 2015

@author: vhd
"""

import scipy
import matplotlib.pyplot as plt
def f1(x):
    return scipy.sin(x**3+1)
def f2(x):
    return scipy.cos(2*x+4)
f3 = lambda x: scipy.cos(3*x+x**4)
f4 = lambda x: scipy.cos(4*x+10)
listf = [f1,f2]
listg=[f3,f4]
x = scipy.linspace(0,2*scipy.pi,50)
fig = plt.figure()
ax1 = fig.add_subplot(221)
ax2 = fig.add_subplot(222)
ax3= fig.add_subplot(223)
ax4= fig.add_subplot(224)
fig.show()
i=1
for i in range(1,100):
    for f in listf:
        y = f(x)
        ax1.clear()
        ax2.clear()
        ax1.plot(x,y,'r')
        ax2.plot(x,y,'b')
        for f in listg:
            ax3.clear()
            ax4.clear()
       
            ax3.plot(x,y,'y')
            ax4.plot(x,y,'g')
            plt.pause(0.1)
        i+=1
    i=i+1