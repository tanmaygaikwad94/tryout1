# -*- coding: utf-8 -*-
"""
Created on Mon Jan 26 10:58:05 2015

@author: KasturiSarang
"""

import scipy
import scipy.optimize as opt
import matplotlib.pyplot as plt
from scipy.integrate import quad
Thin=373; #kelvin
Tcin=303;#kelvin
mh=1; #kg/s 
mc=2; #kg/s
U=300; #W/m2K 
A=10; #m2 
n=1;
#while (n<=15):
while (n<=10):    
    def CpH(T):
        CpH=(4.184+(10**-9)*T**3+(10**-6)*T**2+(10**-4)*T)*1000
        return CpH
    
    def CpC(T):
        CpC=(4.184+(10**-9)*T**3+(10**-6)*T**2+(10**-4)*T)*1000
        return CpC

    def residuals(T,U,A,Thin,Tcin,mh,mc):
        n=len(T)/2
        Th=T[:n]  
        Tc=T[n:]
        dA=A/(n-1) #unknowns at boundaries also, so n/2-1 parts thus divide are
        errHL=(U*(Thin-Tc[0])/(mh*CpH(Thin)))+((Th[1]-Thin)/dA)
        errCL=(U*(Thin-Tc[0])/(mc*CpC(Tc[0])))+((Tc[1]-Tc[0])/dA)
        errHR=(U*(Th[-1]-Tcin)/(mh*CpH(Th[-1])))+((Th[-1]-Th[-2])/dA)
        errCR=(U*(Th[-1]-Tcin)/(mc*CpC(Tcin)))+((Tcin-Tc[-2])/dA)
        errH=scipy.zeros(n)
        errC=scipy.zeros(n)
        errH[0]=errHL; errH[-1]=errHR #errors at boundary points
        errC[0]=errCL;errC[-1]=errCR
        errH[1:-1]=(U*(Th[1:-1]-Tc[1:-1])/(mh*CpH(Th[1:-1])))+((Th[2:])-Th[1:-1])/dA
    #forward
        errC[1:-1]=(U*(Th[1:-1]-Tc[1:-1])/(mc*CpC(Tc[1:-1])))+((Tc[2:])-Tc[1:-1])/dA
        Tguess=scipy.concatenate((Th,Tc))
    #forward
        return scipy.concatenate((errH,errC))
    
        n=len(Tguess)/2   
        soln=opt.leastsq(residuals,Tguess,args=(U,A,Thin,Tcin,mh,mc))
        Tsoln=soln[0]
        Thsoln=Tsoln[:n]
        Thsoln[0]=Thin
        Tcsoln=Tsoln[n:]
        Tcsoln[-1]=Tcin
    
        print Thsoln
        print Tcsoln
    
        b=scipy.linspace(0, 100,n)
        plt.plot(b, Thsoln,'r')
        plt.show()
        plt.plot(b,Tcsoln,'b')
        plt.show()

        solH,err=mh*(quad(CpH,Thsoln[n],Thin))
    
        solC,err=mc*(quad(CpC,Tcsoln[-n],Tcin))
    
        print solH+solC
        ratio=(solH[0]+solC[0])/solH[0]
        print ratio
    
        plt.plot(n, ratio,'r')
        plt.show()
        n=n+1

    