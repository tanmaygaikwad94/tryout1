# -*- coding: utf-8 -*-
"""
Created on Mon Feb 02 21:23:34 2015

@author: Ankit
"""
import scipy
class Fluid:
    def __init__(self,fluidprops):
        self.props=fluidprops
        self.massflowrate=
        self.Temp=
    def H(self,T,P):
        Psat=self.props.Psat(T)
        if P<=Psat:
            Cp=self.props.Cp
            Hfl=self.props.Hf-self.props.Hvap(self.props.Tf)
            H=Hfl+scipy.integrate.quad(Cp,Tf,T)
            return H
        