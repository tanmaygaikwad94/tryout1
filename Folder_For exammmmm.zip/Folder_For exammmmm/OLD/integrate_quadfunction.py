# -*- coding: utf-8 -*-
"""
Created on Tue Jan 20 11:55:53 2015

@author: vhd
"""
import scipy
from scipy.integrate import quad
mh=1;
mc=2

def CpH(T):
    CpH=(4.184+(10**-9)*T**3+(10**-6)*T**2+(10**-4)*T)*1000
    return CpH
def CpC(T):
    CpC=(4.184+(10**-9)*T**3+(10**-6)*T**2+(10**-4)*T)*1000
    return CpC
solH=mh*(quad(CpH,373,343))
print solH
solC=mc*(quad(CpC,303,318))
print solC
print solH+solC
ratio=(solH[0]+solC[0])/solH[0]
print ratio
