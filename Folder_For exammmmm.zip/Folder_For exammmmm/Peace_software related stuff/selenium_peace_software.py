# -*- coding: utf-8 -*-
"""
Created on Mon Jul 20 15:01:25 2015

@author: Ashwin
"""

import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

browser = webdriver.Firefox()
browser.get("http://www.peacesoftware.de/einigewerte/einigewerte_e.html")

elem = browser.find_element_by_link_text("Nitrogen - N2")
elem.click()
elemP = browser.find_element_by_name("druck")
elemT = browser.find_element_by_name("temperatur")

elemP.send_keys('30')
elemT.send_keys('200')
elemCalc = browser.find_element_by_name("Submit")
elemCalc.click()

elemTables = browser.find_elements_by_xpath("//table") #get tables


for table in elemTables:
    rows = table.find_elements_by_xpath("//tr")
    for row in rows:
        td = row.find_elements_by_tag_name('td')
        if str(td[0].text)== 'Pressure :':
            print td[0].text, td[1].text, td[2].text
            
        
    #print td[0], td[1], td[2]


#elem = browser.find_element_by_name("p")
#elem.send_keys('Isaiah 53' + Keys.RETURN)
#
#browser.quit()