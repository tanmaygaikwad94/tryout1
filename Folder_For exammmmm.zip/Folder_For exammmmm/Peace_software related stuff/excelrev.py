# -*- coding: utf-8 -*-
"""
Created on Tue Jul 28 13:40:00 2015

@author: vhd
"""

import win32com.client
import scipy,os
filename='n2.xlsx'
thisdir=os.getcwd()
xl=win32com.client.gencache.EnsureDispatch("Excel.Application")
wb=xl.Workbooks.Open(thisdir+"/"+filename)
xl.Visible=True
sheet=wb.Sheets("Data")

import selenium
import numpy as np
import scipy
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

browser = webdriver.Firefox()
for j in range(10):
    browser.get("http://www.peacesoftware.de/einigewerte/einigewerte_e.html")

    elem = browser.find_element_by_link_text("Nitrogen - N2")
    elem.click()

    elemP = browser.find_element_by_name("druck")
    elemT = browser.find_element_by_name("temperatur")


    elemP.send_keys('1')
    elemT.send_keys(j*10)
    elemCalc = browser.find_element_by_name("Submit")
    elemCalc.click()
    
    body=browser.find_elements_by_tag_name('tbody')
    rows=body[1].find_elements_by_tag_name('tr')
    name=[]
    value=[]
    unit=[]
    for i in range (1,18):
        
        columns1=rows[i].find_elements_by_tag_name('td')
        name.append(columns1[0].text)
        value.append(columns1[1].text)
        unit.append(columns1[2].text)
    
    
    
    sheet.Range(sheet.Cells(1,1),sheet.Cells(1,17)).Value=name
    sheet.Range(sheet.Cells(j+2,1),sheet.Cells(j+2,17)).Value=value
#import scipy as sc
#p=sheet.Range('C2:C11').Value
#print p 
#T=sheet.Range('D2:D11').Value
#print T
#h=sheet.Range('F2:F11').Value
#print h
#calc=sc.interpolate.bisplrep(p,T,h,s=0)
#final=calc(1,10)
#print final
