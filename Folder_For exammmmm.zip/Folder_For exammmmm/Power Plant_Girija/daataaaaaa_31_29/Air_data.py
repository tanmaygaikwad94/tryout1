

import numpy as np
import scipy.interpolate as interp
import win32com.client
import scipy,os
filename='Air.xlsx'
thisdir=os.getcwd()
x1=win32com.client.gencache.EnsureDispatch("Excel.Application")
wb=x1.Workbooks.Open(thisdir + "/" + filename)
x1.Visible=True


sheet=wb.Sheets("Data")

P=np.hstack(np.array(sheet.Range('A2:A101').Value))
T=np.hstack(np.array(sheet.Range('B2:B101').Value))
H=np.hstack(np.array(sheet.Range('D2:D101').Value))
S=np.hstack(np.array(sheet.Range('E2:E101').Value))
Cp=np.hstack(np.array(sheet.Range('F2:F101').Value))
#Cv=np.hstack(np.array(sheet.Range('G2:G101').Value))
rho=np.hstack(np.array(sheet.Range('C2:C101').Value))
inter_s=interp.bisplrep(P,T,S)  
inter_h=interp.bisplrep(P,T,H) 
inter_cp=interp.bisplrep(P,T,Cp)
#inter_cv=interp.bisplrep(P,T,Cv)  