# -*- coding: utf-8 -*-
"""
Created on Mon Aug 10 12:40:10 2015

@author: vhd
"""
import scipy.optimize as opt
import scipy.interpolate as interp
import Nitrogen_data as n2
import Methane_data as ch4
import co2_data as co2
import Oxygen_data as o2
import Air_data as air
import Water_data as steam  #superheated steam
import verify
from scipy import integrate
n=verify.Compound("Nitrogen")  #according to xcel file of perry 
o=verify.Compound('Oxygen')

class data:
    def __init__(self, Name):
        self.name = Name
        
    def entropy(self,P,T):
        name=self.name
        inter_s=interp.bisplrep(name.P,name.T,name.S)
        new=interp.bisplev(P,T,inter_s)
        return new
    def T_SP(self,S,P):
        name=self.name
        inter_T=interp.bisplrep(name.S,name.P,name.T)
        new=interp.bisplev(S,P,inter_T)
        return new
    def enthalpy(self,P,T):
        name=self.name
        inter_h=interp.bisplrep(name.P,name.T,name.H)
        new=interp.bisplev(P,T,inter_h)
        return new
    
        

o1=data(air)
n1=data(n2)
car=data(co2)
wat=data(steam)
met=data(ch4)   

def intg(T):
    q=n.CpIG(T+273)/(T+273)
    return q

def solair(T,P):
    if T>1000:
        N_s=n.Sf+integrate.quad(intg,n.Tf,T+273)[0]
        N_h=n.Hf+integrate.quad(n.CpIG,n.Tf,T+273)[0]
        O_s=o.Sf+integrate.quad(intg,o.Tf,T+273)[0]
        O_h=o.Hf+integrate.quad(o.CpIG,o.Tf,T+273)[0]
    elif T<1000:
        N_s=n1.entropy(P,T)
        N_h=n1.enthalpy(P,T)
        O_s=o1.entropy(P,T)
        O_h=o1.enthalpy(P,T)
    
    x=0.79*N_s*28 + 0.21*O_s*32
    return x
    
def solair_H(T,P):
    if T>1000:
        N_s=n.Sf+integrate.quad(intg,n.Tf,T+273)[0]
        N_h=n.Hf+integrate.quad(n.CpIG,n.Tf,T+273)[0]
        O_s=o.Sf+integrate.quad(intg,o.Tf,T+273)[0]
        O_h=o.Hf+integrate.quad(o.CpIG,o.Tf,T+273)[0]
    elif T<1000:
        N_s=n1.entropy(P,T)
        N_h=n1.enthalpy(P,T)
        O_s=o1.entropy(P,T)
        O_h=o1.enthalpy(P,T)
    
    x=0.79*N_h*28 + 0.21*O_h*32
    return x
    
z=solair(30,1)

def error(T,P):
    c=solair(T,P)-z
    return c
   
    
T=30
soln=opt.leastsq(error,T,10)[0]
print soln


def soln2(T,P):
    if T>1000:
        N_s=n.Sf+integrate.quad(intg,n.Tf,T+273)[0]
        N_h=n.Hf+integrate.quad(n.CpIG,n.Tf,T+273)[0]
        
    elif T<1000:
        N_s=n1.entropy(P,T)
        N_h=n1.enthalpy(P,T)
       
    y=N_h*28 
    return y
    
def solo2(T,P):
    if T>1000:        
        O_s=o.Sf+integrate.quad(intg,o.Tf,T+273)[0]
        O_h=o.Hf+integrate.quad(o.CpIG,o.Tf,T+273)[0]
    elif T<1000:       
        O_s=o1.entropy(P,T)
        O_h=o1.enthalpy(P,T)
    y=O_h*32
    return y
 

n=(10.476)*(solair_H(soln,10))+met.enthalpy(10,30)*16 


def err(T,P): 
    nit=8.276*soln2(T,P)
    oxy=0.2*solo2(T,P)
    carb=1*car.enthalpy(P,T)
    water=2*wat.enthalpy(P,T)
    out=nit+oxy+carb+water
    z=out-n
    return z

solution=opt.leastsq(err,T,10)[0]
print solution 




    
