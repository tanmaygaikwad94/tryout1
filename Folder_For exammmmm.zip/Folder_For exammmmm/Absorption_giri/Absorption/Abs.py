# -*- coding: utf-8 -*-
"""
Created on Wed Mar 11 14:37:26 2015

@author: vhd
"""

import Process_Simulation.input.input as ip
import scipy as sc
import Process_Simulation 
import Process_Simulation.Compounds.water as water
import Process_Simulation.Compounds.methane as CH4
import Process_Simulation.Compounds.carbondioxide as CO2
import Process_Simulation.Compounds.H2S as H2S
import Process_Simulation.fluid.fluid as fluid
import numpy as np
import scipy.optimize as opt


class Abs:
    def __init__(self,a,b,c,d):
        self.a=a
        self.b=b
        self.c=c
        self.d=d
        self.Tlin=ip.Tlin
        self.Tvin=ip.Tvin
        self.L=ip.L
        self.n=ip.n
        self.S=ip.S
        self.Fvin=ip.Fvin
        self.P=ip.P
        self.Fva_in=ip.Fva_in
        self.Fvb_in=ip.Fvb_in
        self.Fvc_in=ip.Fvc_in
        self.Fvd_in=ip.Fvd_in
        
        self.Flin=ip.Flin
        self.Fla_in=ip.Fla_in
        self.Flb_in=ip.Flb_in
        self.Flc_in=ip.Flc_in
        self.Fld_in=ip.Fld_in
        
        self.set_grid(self.n)
        
    def set_grid(self,n):
        self.n=self.n

        self.dx=self.L/(n-1)
       
        
        self.Hv_in=self.Htot(self.Fva_in,self.Fvb_in,self.Fvc_in,self.Fvd_in,self.Fla_in,self.Flb_in,self.Flc_in,self.Fld_in,self.Tvin)[0]
        
        self.Hl_in=self.Htot(self.Fva_in,self.Fvb_in,self.Fvc_in,self.Fvd_in,self.Fla_in,self.Flb_in,self.Flc_in,self.Fld_in,self.Tlin)[1]
   
        '''guess'''
        self.Hvguess=sc.ones(n)*self.Hv_in  #total enthalpy guess
        self.Hlguess=sc.ones(n)*self.Hl_in
        self.Fvaguess=sc.ones(n)*self.Fva_in
        self.Fvbguess=sc.ones(n)*self.Fvb_in
        self.Fvcguess=sc.ones(n)*self.Fvc_in
        self.Fvdguess=sc.ones(n)*self.Fvd_in
        self.Flaguess=sc.ones(n)*self.Fla_in
        self.Flbguess=sc.ones(n)*self.Flb_in
        self.Flcguess=sc.ones(n)*self.Flc_in
        self.Fldguess=sc.ones(n)*self.Fld_in
        self.Tguess=sc.ones(n)*self.Tvin
        
        
        self.guess=sc.concatenate((self.Tguess,self.Fvaguess,self.Fvbguess, self.Fvcguess,self.Fvdguess,self.Flaguess,self.Flbguess,self.Flcguess,self.Fldguess))

        
        
    
    
    def Htot(self,Fva,Fvb,Fvc,Fvd,Fla,Flb,Flc,Fld,T):     #total enthalpy
        a=self.a
        b=self.b
        c=self.c
        d=self.d
        Hv=Fva*a.Hv(T)+Fvb*b.Hv(T)+Fvc*c.Hv(T)+Fvd*b.Hv(T)
        Hl=Fla*a.Hl2(T)+Flb*b.Hl2(T)+Flc*c.Hl2(T)+Fld*d.Hl1(T,d.props.Tsat)
        return Hv,Hl
        

    def solve(self):
        guess=self.guess
        soln=opt.leastsq(residuals,guess,args=(self))[0]
        self.Tsoln=soln[0:self.n]
        
#        self.Hvsoln=soln[0:self.n]
#        self.Hl=guess[self.n:2*self.n]
#        self.Fva=guess[2*self.n:3*self.n]
#        self.Fvb=guess[3*self.n:4*self.n]
#        self.Fvc=guess[4*self.n:5*self.n]
#        self.Fvd=guess[5*self.n:6*self.n]
#        self.Fla=guess[6*self.n:7*self.n]
#        self.Flb=guess[7*self.n:8*self.n]
#        self.Flc=guess[8*self.n:9*self.n]
#        self.Fld=guess[9*self.n:10*self.n]
        
        
        
def residuals(guess,obj):
    n=obj.n
    dx=obj.dx
    P=obj.P
    a=obj.a
    b=obj.b
    c=obj.c
    d=obj.d
    T=guess[0:n]
    Fva=guess[n:2*n]
    Fvb=guess[2*n:3*n]
    Fvc=guess[3*n:4*n]
    Fvd=guess[4*n:5*n]
    Fla=guess[5*n:6*n]
    Flb=guess[6*n:7*n]
    Flc=guess[7*n:8*n]
    Fld=guess[8*n:9*n]
    S=obj.S
    
    Fva_in=obj.Fva_in
    Fvb_in=obj.Fvb_in
    Fvc_in=obj.Fvc_in
    Fvd_in=obj.Fvd_in
    Fla_in=obj.Fla_in
    Flb_in=obj.Flb_in
    Flc_in=obj.Flc_in
    Fld_in=obj.Fld_in
    Tlin=obj.Tlin
    Tvin=obj.Tvin
    Ra_num=sc.ones(n)
    Ra_den=sc.ones(n)
    ErrFva=sc.ones(n)
    ErrFla=sc.ones(n)
    Rb_num=sc.zeros(n)
    Rb_den=sc.zeros(n)
    ErrFvb=sc.zeros(n)
    ErrFlb=sc.zeros(n)
    Rc_num=sc.zeros(n)
    Rc_den=sc.ones(n)
    Rd_num=sc.ones(n)
    Rd_den=sc.ones(n)
    ErrFvc=sc.zeros(n)
    ErrFlc=sc.zeros(n)
    ErrFvd=sc.zeros(n)
    ErrFld=sc.zeros(n)
    
    Ra_num[0]=(((P*obj.Fva_in/(obj.Fva_in+obj.Fvb_in+obj.Fvc_in+obj.Fvd_in))/(a.props.kH(obj.Tvin)))-(Fla[0]*d.props.rho/(Fla[0]+Flb[0]+Flc[0]+Fld[0])))
    Ra_den[0]=(1/((a.props.kH(obj.Tvin)*a.kga(obj.Tvin))))+(1/a.kla(obj.Tvin))
    Rb_num[0]=(((P*obj.Fvb_in/(obj.Fva_in+obj.Fvb_in+obj.Fvc_in+obj.Fvd_in))/(b.props.kH(obj.Tvin)))-(Flb[0]*d.props.rho/(Fla[0]+Flb[0]+Flc[0]+Fld[0])))
    Rb_den[0]=(1/((b.props.kH(obj.Tvin)*b.kga(obj.Tvin))))+(1/b.kla(obj.Tvin))
    Rc_num[0]=(((P*obj.Fvc_in/(obj.Fva_in+obj.Fvb_in+obj.Fvc_in+obj.Fvd_in))/(c.props.kH(obj.Tvin)))-(Flc[0]*d.props.rho/(Fla[0]+Flb[0]+Flc[0]+Fld[0])))
    Rc_den[0]=(1/((c.props.kH(obj.Tvin)*c.kga(obj.Tvin))))+(1/c.kla(obj.Tvin))
    Rd_num[0]=d.kga(Tvin)*(((P*obj.Fvd_in/(obj.Fva_in+obj.Fvb_in+obj.Fvc_in+obj.Fvd_in))-d.props.Psat(Tvin)))
    Rd_den[0]=1
    
    Ra_num[-1]=(((P*Fva[-1]/(Fva[-1]+Fvb[-1]+Fvc[-1]+Fvd[-1]))/(a.props.kH(obj.Tlin)))-(obj.Fla_in*d.props.rho/(obj.Fla_in+obj.Flb_in+obj.Flc_in+obj.Fld_in)))
    Ra_den[-1]=(1/((a.props.kH(obj.Tlin)*a.kga(obj.Tlin))))+(1/a.kla(obj.Tlin))
    Rb_num[-1]=(((P*Fvb[-1]/(Fva[-1]+Fvb[-1]+Fvc[-1]+Fvd[-1]))/(b.props.kH(obj.Tlin)))-(obj.Flb_in*d.props.rho/(obj.Fla_in+obj.Flb_in+obj.Flc_in+obj.Fld_in)))
    Rb_den[-1]=(1/((b.props.kH(obj.Tvin)*b.kga(obj.Tlin))))+(1/b.kla(obj.Tlin))
    Rc_num[-1]=(((P*Fvc[-1]/(Fva[-1]+Fvb[-1]+Fvc[-1]+Fvd[-1]))/(c.props.kH(obj.Tlin)))-(obj.Flc_in*d.props.rho/(obj.Fla_in+obj.Flb_in+obj.Flc_in+obj.Fld_in)))
    Rc_den[-1]=(1/((c.props.kH(obj.Tlin)*c.kga(obj.Tlin))))+(1/c.kla(obj.Tlin))
    Rd_num[-1]=d.kga(Tlin)*(((P*Fvd[-1]/(Fva[-1]+Fvb[-1]+Fvc[-1]+Fvd[-1]))-d.props.Psat(Tlin)))
    Rd_den[-1]=1
    
    
    
    ErrFva[0]=((Fva[1]-obj.Fva_in)/dx)+(S*dx*(Ra_num[0]/Ra_den[0]))
    ErrFla[-1]=((-Fla[-2]+obj.Fla_in)/dx)-(S*dx*(Ra_num[-1]/Ra_den[-1]))
    ErrFvb[0]=((Fvb[1]-obj.Fvb_in)/dx)+S*dx*(Rb_num[0]/Rb_den[0])
    ErrFlb[-1]=((-Flb[-2]+obj.Flb_in)/dx)-S*dx*(Rb_num[-1]/Rb_den[-1])
    ErrFvc[0]=((Fvc[1]-obj.Fvc_in)/dx)+S*dx*(Rc_num[0]/Rc_den[0])
    ErrFlc[-1]=((-Flc[-2]+obj.Flc_in)/dx)-S*dx*(Rc_num[-1]/Rc_den[-1])
    ErrFvd[0]=((Fvd[1]-obj.Fvd_in)/dx)+S*dx*(Rd_num[0]/Rd_den[0])
    ErrFld[-1]=((-Fld[-2]+obj.Fld_in)/dx)-S*dx*(Rd_num[-1]/Rd_den[-1])
    

    
    for i in range(1,n):

        Ra_num[i]=(((P*Fva[i]/(Fva[i]+Fvb[i]+Fvc[i]+Fvd[i]))/(a.props.kH(T[i])))-(Fla[i]*d.props.rho/(Fla[i]+Flb[i]+Flc[i]+Fld[i])))
        Ra_den[i]=(1/((a.props.kH(T[i])*a.kga(T[i]))))+(1/a.kla(T[i]))
        Rb_num[i]=(((P*Fvb[i]/(Fva[i]+Fvb[i]+Fvc[i]+Fvd[i]))/(b.props.kH(T[i])))-(Flb[i]*d.props.rho/(Fla[i]+Flb[i]+Flc[i]+Fld[i])))
        Rb_den[i]=(1/((b.props.kH(T[i])*b.kga(T[i]))))+(1/b.kla(T[i]))
        Rc_num[i]=(((P*Fvc[i]/(Fva[i]+Fvb[i]+Fvc[i]+Fvd[i]))/(c.props.kH(T[i])))-(Flc[i]*d.props.rho/(Fla[i]+Flb[i]+Flc[i]+Fld[i])))
        Rc_den[i]=(1/((c.props.kH(T[i])*c.kga(T[i]))))+(1/c.kla(T[i]))
        Rd_num[i]=d.kga(T[i])*(((P*Fvd[i]/(Fva[i]+Fvb[i]+Fvc[i]+Fvd[i]))-d.props.Psat(T[i])))
        Rd_den[i]=1
    
    
        ErrFva[i]=((Fva[i]-Fva[i-1])/dx)+S*dx*(Ra_num[i]/Ra_den[i])
        ErrFla[i]=((Fla[i]-Fla[i-1])/dx)-S*dx*(Ra_num[i]/Ra_den[i])
        ErrFvb[i]=((Fvb[i]-Fvb[i-1])/dx)+S*dx*(Rb_num[i]/Rb_den[i])
        ErrFlb[i]=((Flb[i]-Flb[i-1])/dx)-S*dx*(Rb_num[i]/Rb_den[i])
        ErrFvc[i]=((Fvc[i]-Fvc[i-1])/dx)+S*dx*(Rc_num[i]/Rc_den[i])
        ErrFlc[i]=((Flc[i]-Flc[i-1])/dx)-S*dx*(Rc_num[i]/Rc_den[i])
        ErrFvd[i]=((Fvd[i]-Fvd[i-1])/dx)+S*dx*(Rd_num[i]/Rd_den[i]) 
        ErrFld[i]=((Fld[i]-Fld[i-1])/dx)-S*dx*(Rd_num[i]/Rd_den[i])
    
    hv=sc.zeros(n)
    hl=sc.zeros(n)
    errH=sc.zeros(n)
    hv[0]=obj.Htot(Fva_in,Fvb_in,Fvc_in,Fvd_in,Fla[0],Flb[0],Flc[0],Fld[0],Tvin)[0]
    hl[0]=obj.Htot(Fva_in,Fvb_in,Fvc_in,Fvd_in,Fla[0],Flb[0],Flc[0],Fld[0],Tvin)[1]
    hv[-1]=obj.Htot(Fva[-1],Fvb[-1],Fvc[-1],Fvd[-1],Fla_in,Flb_in,Flc_in,Fld_in,Tlin)[0]
    hl[-1]=obj.Htot(Fva[-1],Fvb[-1],Fvc[-1],Fvd[-1],Fla_in,Flb_in,Flc_in,Fld_in,Tlin)[1]
    
    
    for i in range (1,n):
        hv[i]=Fva[i]*a.Hv(T[i])+Fvb[i]*b.Hv(T[i])+Fvc[i]*c.Hv(T[i])+Fvd[i]*d.Hv(T[i])
        hl[i]=Fla[i]*a.Hl2(T[i])+Flb[i]*b.Hl2(T[i])+Flc[i]*c.Hl2(T[i])+Fld[i]*d.Hl1(T[i],d.props.Tsat)
      
        
    errH=(np.gradient(hv)/dx)-(np.gradient(hl)/dx)
    
    
    return sc.concatenate((errH,ErrFva,ErrFvb,ErrFvc,ErrFvd,ErrFla,ErrFlb,ErrFlc,ErrFld))
    
            
a=fluid.Fluid(CH4)
b=fluid.Fluid(CO2)
c=fluid.Fluid(H2S)
d=fluid.Fluid(water)

Abs=Abs(a,b,c,d)

a=Abs.solve()

print Abs.Tsoln


 
        
        
        
        