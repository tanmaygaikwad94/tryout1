# -*- coding: utf-8 -*-
"""
Created on Wed Mar 11 14:27:40 2015

@author: vhd
"""
import scipy as sc
L=6 #m
D=0.9 #m
P=101325 #Pa
n=10
Tvin=303.15 #K
Tlin=303.15

Fvin=100 #kmol/s

Fva_in=0.5*Fvin
Fvb_in=0.45*Fvin
Fvc_in=0.05*Fvin
Fvd_in=0

Flin=1000 #kmol/s
Fla_in=0
Flb_in=0
Flc_in=0
Fld_in=Flin

S=(sc.pi*D**2)/4






